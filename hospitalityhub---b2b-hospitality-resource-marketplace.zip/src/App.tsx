/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Building2, 
  Sparkles, 
  SlidersHorizontal, 
  ArrowUpDown, 
  X, 
  Check, 
  Heart,
  PlusCircle,
  Package,
  Layers,
  ArrowRight
} from 'lucide-react';

import { 
  Resource, 
  CategoryKey, 
  BookingType, 
  BookingRequest, 
  NegotiationOffer, 
  PhotoAudit, 
  ProviderProfile, 
  Language, 
  ActiveTab 
} from './types';

import { 
  INITIAL_RESOURCES, 
  INITIAL_PROVIDERS, 
  INITIAL_BOOKINGS, 
  INITIAL_NEGOTIATIONS, 
  INITIAL_AUDITS 
} from './data/mockData';

import { translations } from './data/translations';

// Components
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { SearchFilterBar } from './components/SearchFilterBar';
import { ResourceCard } from './components/ResourceCard';
import { ResourceDetailsModal } from './components/ResourceDetailsModal';
import { RequestRentalModal } from './components/RequestRentalModal';
import { NegotiateModal } from './components/NegotiateModal';
import { CompareModal } from './components/CompareModal';
import { CompareFloatingBar } from './components/CompareFloatingBar';
import { ListResourceModal } from './components/ListResourceModal';
import { DashboardView } from './components/DashboardView';
import { ProvidersView } from './components/ProvidersView';
import { HowItWorksView } from './components/HowItWorksView';
import { TrustSection } from './components/TrustSection';
import { NotificationsModal } from './components/NotificationsModal';
import { Footer } from './components/Footer';

export default function App() {
  // Global Language & Theme
  const [lang, setLang] = useState<Language>('en');
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const t = translations[lang];

  // Active top navigation tab
  const [activeTab, setActiveTab] = useState<ActiveTab>('marketplace');

  // Application Data States
  const [resources, setResources] = useState<Resource[]>(INITIAL_RESOURCES);
  const [providers] = useState<ProviderProfile[]>(INITIAL_PROVIDERS);
  const [bookings, setBookings] = useState<BookingRequest[]>(INITIAL_BOOKINGS);
  const [negotiations, setNegotiations] = useState<NegotiationOffer[]>(INITIAL_NEGOTIATIONS);
  const [audits] = useState<PhotoAudit[]>(INITIAL_AUDITS);

  // User interactions: Favorites & Comparison
  const [savedIds, setSavedIds] = useState<number[]>([1, 2]);
  const [compareIds, setCompareIds] = useState<number[]>([]);
  const [showSavedOnly, setShowSavedOnly] = useState(false);

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [locationFilter, setLocationFilter] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateUntil, setDateUntil] = useState('');
  const [quantityFilter, setQuantityFilter] = useState(1);
  const [bookingTypeFilter, setBookingTypeFilter] = useState<'all' | BookingType>('all');
  const [activeCategory, setActiveCategory] = useState<CategoryKey>('all');
  const [sortBy, setSortBy] = useState<'match' | 'price-asc' | 'price-desc' | 'rating'>('match');

  // Modals state
  const [detailsModalResource, setDetailsModalResource] = useState<Resource | null>(null);
  const [rentalModalResource, setRentalModalResource] = useState<Resource | null>(null);
  const [negotiateModalResource, setNegotiateModalResource] = useState<Resource | null>(null);
  const [isCompareModalOpen, setIsCompareModalOpen] = useState(false);
  const [isListModalOpen, setIsListModalOpen] = useState(false);
  const [isNotificationsModalOpen, setIsNotificationsModalOpen] = useState(false);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Sync theme with HTML class
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const toggleLang = () => {
    setLang((prev) => (prev === 'en' ? 'hi' : 'en'));
  };

  // Favorite toggle
  const toggleSaveResource = (id: number) => {
    if (savedIds.includes(id)) {
      setSavedIds(savedIds.filter((item) => item !== id));
      showToast(lang === 'hi' ? 'संसाधन सहेजे से हटाया गया' : 'Resource removed from saved');
    } else {
      setSavedIds([...savedIds, id]);
      showToast(lang === 'hi' ? 'संसाधन सहेज लिया गया' : 'Resource saved to favorites');
    }
  };

  // Compare toggle (max 3)
  const toggleCompareResource = (id: number) => {
    if (compareIds.includes(id)) {
      setCompareIds(compareIds.filter((item) => item !== id));
    } else {
      if (compareIds.length >= 3) {
        showToast(lang === 'hi' ? 'अधिकतम 3 संसाधनों की तुलना की जा सकती है' : 'You can compare maximum 3 resources at a time');
        return;
      }
      setCompareIds([...compareIds, id]);
      showToast(lang === 'hi' ? 'तुलना ट्रे में जोड़ा गया' : 'Added to comparison tray');
    }
  };

  const clearCompare = () => {
    setCompareIds([]);
    setIsCompareModalOpen(false);
  };

  const removeCompareItem = (id: number) => {
    setCompareIds(compareIds.filter((item) => item !== id));
  };

  // Reset filters
  const resetFilters = () => {
    setSearchQuery('');
    setLocationFilter('');
    setDateFrom('');
    setDateUntil('');
    setQuantityFilter(1);
    setBookingTypeFilter('all');
    setActiveCategory('all');
    setShowSavedOnly(false);
    showToast(lang === 'hi' ? 'सभी फ़िल्टर साफ़ कर दिए गए' : 'Filters cleared');
  };

  const hasActiveFilters = 
    Boolean(searchQuery) || 
    Boolean(locationFilter) || 
    Boolean(dateFrom) || 
    Boolean(dateUntil) || 
    bookingTypeFilter !== 'all' || 
    activeCategory !== 'all' || 
    showSavedOnly;

  // Filtered & sorted resources
  const filteredResources = useMemo(() => {
    return resources.filter((res) => {
      if (showSavedOnly && !savedIds.includes(res.id)) {
        return false;
      }
      if (activeCategory !== 'all' && res.category !== activeCategory) {
        return false;
      }
      if (locationFilter && res.city.toLowerCase() !== locationFilter.toLowerCase()) {
        return false;
      }
      if (bookingTypeFilter !== 'all' && res.booking !== bookingTypeFilter) {
        return false;
      }
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const matchesName = res.name.toLowerCase().includes(q);
        const matchesProvider = res.provider.toLowerCase().includes(q);
        const matchesDesc = res.description.toLowerCase().includes(q);
        const matchesSpecs = res.specs.some((s) => s.toLowerCase().includes(q));
        if (!matchesName && !matchesProvider && !matchesDesc && !matchesSpecs) {
          return false;
        }
      }
      // Date filter check against lockedDates
      if (dateFrom && res.lockedDates?.includes(dateFrom)) {
        return false;
      }
      if (dateUntil && res.lockedDates?.includes(dateUntil)) {
        return false;
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'rating') return Number(b.rating) - Number(a.rating);
      return b.match - a.match;
    });
  }, [resources, showSavedOnly, savedIds, activeCategory, locationFilter, bookingTypeFilter, searchQuery, dateFrom, dateUntil, sortBy]);

  // Handling new resource creation
  const handleAddResource = (newRes: Resource) => {
    setResources([newRes, ...resources]);
    showToast(t.listingAdded);
    setActiveTab('marketplace');
  };

  // Handling booking submission
  const handleConfirmBooking = (newBooking: BookingRequest) => {
    setBookings([newBooking, ...bookings]);
    // Also lock dates on resource
    setResources(
      resources.map((r) => {
        if (r.id === newBooking.resourceId) {
          const currentLocked = r.lockedDates || [];
          return {
            ...r,
            lockedDates: [...currentLocked, newBooking.dateFrom, newBooking.dateUntil],
            rentals: r.rentals + 1
          };
        }
        return r;
      })
    );
    showToast(t.bookingConfirmed);
  };

  // Handling negotiation offer
  const handleSubmitOffer = (newOffer: NegotiationOffer) => {
    setNegotiations([newOffer, ...negotiations]);
    showToast(t.offerSent);
  };

  const handleAcceptOffer = (id: string) => {
    setNegotiations(
      negotiations.map((n) => (n.id === id ? { ...n, status: 'accepted' } : n))
    );
    showToast(t.offerAccepted);
  };

  const handleRejectOffer = (id: string) => {
    setNegotiations(
      negotiations.map((n) => (n.id === id ? { ...n, status: 'rejected' } : n))
    );
    showToast(t.offerRejected);
  };

  const handleCounterOffer = (id: string, counterPrice: number) => {
    setNegotiations(
      negotiations.map((n) =>
        n.id === id ? { ...n, status: 'countered', counterPrice } : n
      )
    );
    showToast(t.offerCountered);
  };

  const handleToggleResourceStatus = (id: number) => {
    setResources(
      resources.map((r) => {
        if (r.id === id) {
          const nextStatus = r.status === 'available' ? 'unavailable' : 'available';
          return { ...r, status: nextStatus };
        }
        return r;
      })
    );
  };

  const handleFilterByProvider = (providerName: string) => {
    setSearchQuery(providerName);
    setActiveTab('marketplace');
  };

  const comparedResources = useMemo(() => {
    return resources.filter((r) => compareIds.includes(r.id));
  }, [resources, compareIds]);

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground transition-colors selection:bg-primary/20 selection:text-primary">
      
      {/* Navigation Header */}
      <Navbar
        lang={lang}
        onToggleLang={toggleLang}
        theme={theme}
        onToggleTheme={toggleTheme}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenListModal={() => setIsListModalOpen(true)}
        savedCount={savedIds.length}
        showSavedOnly={showSavedOnly}
        onToggleSavedOnly={() => {
          setShowSavedOnly(!showSavedOnly);
          if (activeTab !== 'marketplace') setActiveTab('marketplace');
        }}
        notificationCount={3}
        onOpenNotifications={() => setIsNotificationsModalOpen(true)}
      />

      {/* Main Content Router */}
      <main className="flex-1">
        {/* VIEW: MARKETPLACE OR RESOURCES (Main Catalog) */}
        {(activeTab === 'marketplace' || activeTab === 'resources') && (
          <div>
            {/* Hero Section */}
            {activeTab === 'marketplace' && (
              <HeroSection
                lang={lang}
                onExploreClick={() => {
                  const el = document.getElementById('catalog-section');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }}
                onListClick={() => setIsListModalOpen(true)}
              />
            )}

            {/* Search & Category Filter Bar */}
            <SearchFilterBar
              lang={lang}
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              locationFilter={locationFilter}
              onLocationChange={setLocationFilter}
              dateFrom={dateFrom}
              onDateFromChange={setDateFrom}
              dateUntil={dateUntil}
              onDateUntilChange={setDateUntil}
              quantityFilter={quantityFilter}
              onQuantityChange={setQuantityFilter}
              bookingTypeFilter={bookingTypeFilter}
              onBookingTypeChange={setBookingTypeFilter}
              activeCategory={activeCategory}
              onSelectCategory={setActiveCategory}
              onResetFilters={resetFilters}
              hasActiveFilters={hasActiveFilters}
            />

            {/* Catalog Grid Section matching reference */}
            <section id="catalog-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
              
              {/* Section Header with count & sort */}
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6 pb-4 border-b border-border">
                <div>
                  <div className="text-xs uppercase font-bold tracking-wider text-primary mb-1">
                    {t.resources}
                  </div>
                  <h2 className="font-serif text-2xl sm:text-3xl text-foreground font-normal">
                    {showSavedOnly ? t.saved : t.featured}
                  </h2>
                  <p className="text-xs sm:text-sm text-muted-foreground mt-1">
                    {showSavedOnly ? `${savedIds.length} resources saved` : t.featuredSub}
                  </p>
                </div>

                {/* Right controls: count badge & sorting */}
                <div className="flex items-center gap-3 self-start sm:self-auto">
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-muted text-muted-foreground">
                    {filteredResources.length} {lang === 'hi' ? 'संसाधन' : 'resources'}
                  </span>

                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <ArrowUpDown className="w-3.5 h-3.5" />
                    <select
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value as any)}
                      aria-label={t.sortBy}
                      className="bg-card border border-border rounded-md px-2 py-1 text-xs text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                    >
                      <option value="match">{t.sortMatch}</option>
                      <option value="price-asc">{t.sortPriceLow}</option>
                      <option value="price-desc">{t.sortPriceHigh}</option>
                      <option value="rating">{t.sortRating}</option>
                    </select>
                  </div>

                  {hasActiveFilters && (
                    <button
                      onClick={resetFilters}
                      className="text-xs font-bold text-primary hover:underline ml-1"
                    >
                      {t.reset}
                    </button>
                  )}
                </div>
              </div>

              {/* Resource Cards Grid */}
              {filteredResources.length === 0 ? (
                <div className="p-16 text-center bg-card rounded-2xl border border-border shadow-xs my-6 space-y-4">
                  <Package className="w-12 h-12 mx-auto text-muted-foreground/40" />
                  <div>
                    <h3 className="font-serif text-lg font-bold text-foreground">
                      {t.noResults}
                    </h3>
                    <p className="text-xs text-muted-foreground mt-1 max-w-sm mx-auto">
                      Try adjusting your date range, location, or search keywords to view available hospitality equipment and spaces.
                    </p>
                  </div>
                  <button
                    onClick={resetFilters}
                    className="px-4 py-2 bg-primary text-primary-foreground text-xs font-semibold rounded-lg hover:bg-primary/90 transition-colors shadow-xs"
                  >
                    {t.reset}
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
                  {filteredResources.map((resource) => (
                    <ResourceCard
                      key={resource.id}
                      resource={resource}
                      lang={lang}
                      isSaved={savedIds.includes(resource.id)}
                      onToggleSave={toggleSaveResource}
                      isCompared={compareIds.includes(resource.id)}
                      onToggleCompare={toggleCompareResource}
                      onViewDetails={(res) => setDetailsModalResource(res)}
                      onRequestRental={(res) => setRentalModalResource(res)}
                      onNegotiate={(res) => setNegotiateModalResource(res)}
                    />
                  ))}
                </div>
              )}
            </section>

            {/* Homepage Trust Section & Workflow */}
            {activeTab === 'marketplace' && (
              <>
                <TrustSection lang={lang} />
                
                {/* How It Works Micro Section */}
                <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
                  <div className="text-center max-w-2xl mx-auto mb-12">
                    <span className="text-xs font-bold uppercase tracking-wider text-primary">
                      {t.how}
                    </span>
                    <h2 className="font-serif text-2xl sm:text-4xl font-bold text-foreground mt-2">
                      {t.process}
                    </h2>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div className="p-6 rounded-2xl border border-border bg-card shadow-xs space-y-3">
                      <div className="font-serif text-3xl font-bold text-primary/40">01</div>
                      <h3 className="font-serif font-bold text-lg text-foreground">{t.step1}</h3>
                      <p className="text-xs text-muted-foreground leading-relaxed">{t.step1Text}</p>
                    </div>

                    <div className="p-6 rounded-2xl border border-border bg-card shadow-xs space-y-3">
                      <div className="font-serif text-3xl font-bold text-primary/40">02</div>
                      <h3 className="font-serif font-bold text-lg text-foreground">{t.step2}</h3>
                      <p className="text-xs text-muted-foreground leading-relaxed">{t.step2Text}</p>
                    </div>

                    <div className="p-6 rounded-2xl border border-border bg-card shadow-xs space-y-3">
                      <div className="font-serif text-3xl font-bold text-primary/40">03</div>
                      <h3 className="font-serif font-bold text-lg text-foreground">{t.step3}</h3>
                      <p className="text-xs text-muted-foreground leading-relaxed">{t.step3Text}</p>
                    </div>
                  </div>
                </section>

                {/* Idle Resource Banner */}
                <section className="bg-primary text-primary-foreground py-14">
                  <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-6">
                    <div className="space-y-1.5 text-center sm:text-left">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-[#9be8d0]">
                        {t.providerView}
                      </span>
                      <h3 className="font-serif text-2xl sm:text-3xl font-normal text-white">
                        {t.ctaTitle}
                      </h3>
                      <p className="text-xs sm:text-sm text-[#d0dfd9]">
                        {t.ctaText}
                      </p>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <button
                        onClick={() => setIsListModalOpen(true)}
                        className="px-5 py-2.5 rounded-lg bg-white text-primary font-bold text-xs sm:text-sm hover:bg-neutral-100 transition-colors shadow-md active:scale-95"
                      >
                        {t.listYours}
                      </button>
                    </div>
                  </div>
                </section>
              </>
            )}
          </div>
        )}

        {/* VIEW: PROVIDERS DIRECTORY */}
        {activeTab === 'providers' && (
          <ProvidersView
            providers={providers}
            lang={lang}
            onFilterByProvider={handleFilterByProvider}
          />
        )}

        {/* VIEW: HOW IT WORKS */}
        {activeTab === 'how' && (
          <HowItWorksView
            lang={lang}
            onExploreClick={() => setActiveTab('marketplace')}
            onListClick={() => setIsListModalOpen(true)}
          />
        )}

        {/* VIEW: DASHBOARD */}
        {activeTab === 'dashboard' && (
          <DashboardView
            lang={lang}
            resources={resources}
            bookings={bookings}
            negotiations={negotiations}
            audits={audits}
            onOpenListModal={() => setIsListModalOpen(true)}
            onAcceptOffer={handleAcceptOffer}
            onRejectOffer={handleRejectOffer}
            onCounterOffer={handleCounterOffer}
            onToggleResourceStatus={handleToggleResourceStatus}
          />
        )}
      </main>

      {/* Floating Compare Action Bar */}
      <CompareFloatingBar
        resources={comparedResources}
        lang={lang}
        onOpenCompare={() => setIsCompareModalOpen(true)}
        onClear={clearCompare}
      />

      {/* Footer */}
      <Footer
        lang={lang}
        onSelectTab={setActiveTab}
        onSelectCategory={(cat) => {
          setActiveCategory(cat);
          setActiveTab('marketplace');
        }}
        onOpenListModal={() => setIsListModalOpen(true)}
      />

      {/* MODALS */}
      {/* 1. Resource Details Modal */}
      {detailsModalResource && (
        <ResourceDetailsModal
          resource={detailsModalResource}
          lang={lang}
          onClose={() => setDetailsModalResource(null)}
          onRequestRental={(res) => setRentalModalResource(res)}
          onNegotiate={(res) => setNegotiateModalResource(res)}
        />
      )}

      {/* 2. Request Rental & Payment Review Modal */}
      {rentalModalResource && (
        <RequestRentalModal
          resource={rentalModalResource}
          lang={lang}
          onClose={() => setRentalModalResource(null)}
          onConfirmBooking={handleConfirmBooking}
        />
      )}

      {/* 3. Negotiate / Make Offer Modal */}
      {negotiateModalResource && (
        <NegotiateModal
          resource={negotiateModalResource}
          lang={lang}
          onClose={() => setNegotiateModalResource(null)}
          onSubmitOffer={handleSubmitOffer}
        />
      )}

      {/* 4. Compare Modal */}
      {isCompareModalOpen && (
        <CompareModal
          resources={comparedResources}
          lang={lang}
          onClose={() => setIsCompareModalOpen(false)}
          onRemove={removeCompareItem}
          onClearAll={clearCompare}
          onRequestRental={(res) => {
            setIsCompareModalOpen(false);
            setRentalModalResource(res);
          }}
        />
      )}

      {/* 5. List a Resource Modal */}
      {isListModalOpen && (
        <ListResourceModal
          lang={lang}
          onClose={() => setIsListModalOpen(false)}
          onAddResource={handleAddResource}
        />
      )}

      {/* 6. Notifications Modal */}
      {isNotificationsModalOpen && (
        <NotificationsModal
          lang={lang}
          onClose={() => setIsNotificationsModalOpen(false)}
          onViewDashboard={() => {
            setIsNotificationsModalOpen(false);
            setActiveTab('dashboard');
          }}
        />
      )}

      {/* Toast Notification message */}
      {toastMessage && (
        <aside aria-label="Notification" className="fixed bottom-6 right-6 z-50 bg-[#163f35] text-white px-4 py-2.5 rounded-xl border border-[#2b6858] shadow-2xl text-xs font-semibold flex items-center gap-2 animate-in slide-in-from-bottom-3 duration-200">
          <Sparkles className="w-4 h-4 text-[#e5c278] shrink-0" />
          <span>{toastMessage}</span>
        </aside>
      )}

    </div>
  );
}
