import React from 'react';
import { Scale, X, ArrowRight } from 'lucide-react';
import { Resource, Language } from '../types';
import { translations } from '../data/translations';

interface CompareFloatingBarProps {
  resources: Resource[];
  lang: Language;
  onOpenCompare: () => void;
  onClear: () => void;
}

export const CompareFloatingBar: React.FC<CompareFloatingBarProps> = ({
  resources,
  lang,
  onOpenCompare,
  onClear,
}) => {
  if (resources.length === 0) return null;

  const t = translations[lang];

  return (
    <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-40 bg-card border border-border shadow-2xl rounded-2xl p-2.5 sm:px-4 sm:py-3 flex items-center gap-3 sm:gap-4 max-w-[95vw] sm:max-w-xl animate-in slide-in-from-bottom-5 duration-300">
      <div className="flex items-center gap-2">
        <div className="p-1.5 rounded-lg bg-primary text-primary-foreground">
          <Scale className="w-4 h-4" />
        </div>
        <div className="hidden sm:block text-xs font-semibold text-foreground">
          {resources.length} {t.selected}
        </div>
      </div>

      {/* Mini Thumbnails */}
      <div className="flex items-center -space-x-2">
        {resources.map((r) => (
          <img
            key={r.id}
            src={r.image}
            alt={r.name}
            className="w-8 h-8 rounded-full border-2 border-card object-cover"
            title={r.name}
          />
        ))}
      </div>

      <div className="flex items-center gap-2 ml-auto">
        <button
          onClick={onOpenCompare}
          className="py-1.5 px-3 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:bg-[#133c32] shadow-xs flex items-center gap-1.5 transition-colors"
        >
          <span>{t.compareNow}</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>

        <button
          onClick={onClear}
          className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
          title={t.clear}
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
