import React from 'react';
import { 
  X, 
  Scale, 
  Trash2, 
  ArrowRight, 
  Star, 
  MapPin, 
  ShieldCheck, 
  Check 
} from 'lucide-react';
import { Resource, Language } from '../types';
import { translations } from '../data/translations';

interface CompareModalProps {
  resources: Resource[];
  lang: Language;
  onClose: () => void;
  onRemove: (id: number) => void;
  onClearAll: () => void;
  onRequestRental: (resource: Resource) => void;
}

export const CompareModal: React.FC<CompareModalProps> = ({
  resources,
  lang,
  onClose,
  onRemove,
  onClearAll,
  onRequestRental,
}) => {
  const t = translations[lang];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div 
        className="bg-card w-full max-w-5xl rounded-2xl border border-border shadow-2xl overflow-hidden my-auto relative animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-border bg-muted/40">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-primary/10 text-primary">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-serif text-xl font-bold text-foreground">
                {t.compareResources}
              </h2>
              <p className="text-xs text-muted-foreground">
                Comparing {resources.length} selected hospitality resource{resources.length > 1 ? 's' : ''}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onClearAll}
              className="text-xs font-semibold text-rose-600 hover:text-rose-700 flex items-center gap-1"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{t.clear}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {resources.length === 0 ? (
          <div className="p-12 text-center text-muted-foreground">
            <Scale className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">{t.compareEmpty}</p>
          </div>
        ) : (
          <div className="p-5 sm:p-6 overflow-x-auto max-h-[75vh]">
            <table className="w-full min-w-[640px] text-left border-collapse">
              <thead>
                <tr className="border-b border-border">
                  <th className="p-3 text-xs font-bold text-muted-foreground w-1/4">Criteria</th>
                  {resources.map((item) => (
                    <th key={item.id} className="p-3 align-top w-1/4">
                      <div className="relative aspect-[16/10] rounded-lg overflow-hidden bg-muted mb-2">
                        <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                        <button
                          onClick={() => onRemove(item.id)}
                          className="absolute top-1.5 right-1.5 p-1 bg-black/60 hover:bg-black text-white rounded-full"
                          title={t.remove}
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                      <h4 className="font-serif font-bold text-sm text-foreground line-clamp-1">{item.name}</h4>
                      <p className="text-[11px] text-muted-foreground truncate">{item.provider}</p>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border text-xs">
                {/* Price */}
                <tr>
                  <td className="p-3 font-semibold text-muted-foreground">{t.price}</td>
                  {resources.map((item) => (
                    <td key={item.id} className="p-3 font-bold text-foreground">
                      <span className="font-serif text-base text-primary">₹{item.price.toLocaleString('en-IN')}</span>
                      <span className="text-muted-foreground text-[11px]"> / {item.unit === 'day' ? t.day : t.eventUnit}</span>
                    </td>
                  ))}
                </tr>

                {/* Location */}
                <tr>
                  <td className="p-3 font-semibold text-muted-foreground">{t.location}</td>
                  {resources.map((item) => (
                    <td key={item.id} className="p-3">
                      <span className="inline-flex items-center gap-1 font-medium">
                        <MapPin className="w-3.5 h-3.5 text-muted-foreground" />
                        {item.city}
                      </span>
                    </td>
                  ))}
                </tr>

                {/* Match Score */}
                <tr>
                  <td className="p-3 font-semibold text-muted-foreground">{t.match}</td>
                  {resources.map((item) => (
                    <td key={item.id} className="p-3">
                      <span className="px-2 py-0.5 rounded-sm bg-primary/10 text-primary font-bold text-[11px]">
                        {item.match}% Match
                      </span>
                    </td>
                  ))}
                </tr>

                {/* Rating */}
                <tr>
                  <td className="p-3 font-semibold text-muted-foreground">{t.rating}</td>
                  {resources.map((item) => (
                    <td key={item.id} className="p-3">
                      <div className="flex items-center gap-1">
                        <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                        <span className="font-bold">{item.rating}</span>
                        <span className="text-muted-foreground">({item.reviews})</span>
                      </div>
                    </td>
                  ))}
                </tr>

                {/* Booking Type */}
                <tr>
                  <td className="p-3 font-semibold text-muted-foreground">{t.bookingType}</td>
                  {resources.map((item) => (
                    <td key={item.id} className="p-3 capitalize font-medium">
                      {item.booking === 'planned' ? `▦ ${t.planned}` : `⚡ ${t.emergency}`}
                    </td>
                  ))}
                </tr>

                {/* Key Specs */}
                <tr>
                  <td className="p-3 font-semibold text-muted-foreground">{t.specifications}</td>
                  {resources.map((item) => (
                    <td key={item.id} className="p-3 align-top">
                      <ul className="space-y-1">
                        {item.specs.map((spec, i) => (
                          <li key={i} className="flex items-center gap-1 text-[11px] text-foreground">
                            <Check className="w-3 h-3 text-emerald-600 shrink-0" />
                            <span>{spec}</span>
                          </li>
                        ))}
                      </ul>
                    </td>
                  ))}
                </tr>

                {/* Action */}
                <tr>
                  <td className="p-3 font-semibold text-muted-foreground">Action</td>
                  {resources.map((item) => (
                    <td key={item.id} className="p-3">
                      <button
                        onClick={() => {
                          onClose();
                          onRequestRental(item);
                        }}
                        className="w-full py-2 bg-primary text-primary-foreground text-xs font-semibold rounded-lg hover:bg-[#133c32] shadow-xs flex items-center justify-center gap-1.5"
                      >
                        <span>{t.request}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
