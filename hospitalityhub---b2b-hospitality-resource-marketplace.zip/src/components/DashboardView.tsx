import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Package, 
  Calendar, 
  MessageSquare, 
  Camera, 
  TrendingUp, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  ArrowRight, 
  Plus, 
  ShieldCheck, 
  ArrowUpDown,
  CircleDollarSign,
  Building,
  User,
  Truck
} from 'lucide-react';
import { 
  Resource, 
  BookingRequest, 
  NegotiationOffer, 
  PhotoAudit, 
  Language 
} from '../types';
import { translations } from '../data/translations';

interface DashboardViewProps {
  lang: Language;
  resources: Resource[];
  bookings: BookingRequest[];
  negotiations: NegotiationOffer[];
  audits: PhotoAudit[];
  onOpenListModal: () => void;
  onAcceptOffer: (id: string) => void;
  onRejectOffer: (id: string) => void;
  onCounterOffer: (id: string, counterPrice: number) => void;
  onToggleResourceStatus: (id: number) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  lang,
  resources,
  bookings,
  negotiations,
  audits,
  onOpenListModal,
  onAcceptOffer,
  onRejectOffer,
  onCounterOffer,
  onToggleResourceStatus,
}) => {
  const t = translations[lang];

  // Workspace mode
  const [workspace, setWorkspace] = useState<'provider' | 'seeker'>('provider');
  const [activeTab, setActiveTab] = useState<'overview' | 'resources' | 'bookings' | 'negotiations' | 'audits'>('overview');
  
  // Counter offer modal state
  const [counterModalOpen, setCounterModalOpen] = useState(false);
  const [activeOfferToCounter, setActiveOfferToCounter] = useState<NegotiationOffer | null>(null);
  const [counterPriceInput, setCounterPriceInput] = useState<number>(0);

  // Computations
  const activeCount = resources.filter((r) => r.status === 'available').length;
  const bookedCount = bookings.filter((b) => b.status === 'accepted').length;
  const pendingRequestsCount = bookings.filter((b) => b.status === 'pending').length;
  const totalRevenue = bookings
    .filter((b) => b.status === 'accepted' || b.status === 'completed')
    .reduce((sum, b) => sum + b.total, 0);

  const openCounterDialog = (offer: NegotiationOffer) => {
    setActiveOfferToCounter(offer);
    setCounterPriceInput(offer.proposedPrice + 500);
    setCounterModalOpen(true);
  };

  const submitCounter = (e: React.FormEvent) => {
    e.preventDefault();
    if (activeOfferToCounter && counterPriceInput > 0) {
      onCounterOffer(activeOfferToCounter.id, counterPriceInput);
      setCounterModalOpen(false);
      setActiveOfferToCounter(null);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      
      {/* Header bar with Role Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-border">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-primary">
            HospitalityHub B2B Ops
          </span>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-foreground mt-1">
            {t.dashboard}
          </h1>
          <p className="text-xs sm:text-sm text-muted-foreground mt-0.5">
            {workspace === 'provider' ? 'Manage your fleet, venue assets & booking revenue' : 'Track your rental requests, negotiations & active bookings'}
          </p>
        </div>

        {/* Workspace Switcher */}
        <div className="flex items-center gap-3">
          <div className="inline-flex rounded-lg border border-border bg-card p-1 shadow-xs">
            <button
              onClick={() => setWorkspace('provider')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all flex items-center gap-1.5 ${
                workspace === 'provider'
                  ? 'bg-primary text-primary-foreground shadow-xs'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <Building className="w-3.5 h-3.5" />
              <span>{t.providerView}</span>
            </button>
            <button
              onClick={() => setWorkspace('seeker')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all flex items-center gap-1.5 ${
                workspace === 'seeker'
                  ? 'bg-primary text-primary-foreground shadow-xs'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>{t.seekerView}</span>
            </button>
          </div>

          {workspace === 'provider' && (
            <button
              onClick={onOpenListModal}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-primary text-primary-foreground hover:bg-[#133c32] shadow-xs transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{t.addListing}</span>
            </button>
          )}
        </div>
      </div>

      {/* KPI Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 my-6">
        <div className="p-4 sm:p-5 rounded-xl bg-card border border-border shadow-xs">
          <div className="flex items-center justify-between text-muted-foreground text-xs">
            <span>{t.activeResources}</span>
            <Package className="w-4 h-4 text-primary" />
          </div>
          <div className="font-serif text-2xl sm:text-3xl font-bold text-foreground mt-2">
            {activeCount}
          </div>
          <span className="text-[11px] text-emerald-600 font-medium">● Ready in marketplace</span>
        </div>

        <div className="p-4 sm:p-5 rounded-xl bg-card border border-border shadow-xs">
          <div className="flex items-center justify-between text-muted-foreground text-xs">
            <span>{t.bookedResources}</span>
            <Calendar className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="font-serif text-2xl sm:text-3xl font-bold text-foreground mt-2">
            {bookedCount}
          </div>
          <span className="text-[11px] text-muted-foreground font-medium">Calendar locked</span>
        </div>

        <div className="p-4 sm:p-5 rounded-xl bg-card border border-border shadow-xs">
          <div className="flex items-center justify-between text-muted-foreground text-xs">
            <span>{t.pendingRequests}</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <div className="font-serif text-2xl sm:text-3xl font-bold text-foreground mt-2">
            {pendingRequestsCount + negotiations.filter(n => n.status === 'pending').length}
          </div>
          <span className="text-[11px] text-amber-600 font-medium">Awaiting action</span>
        </div>

        <div className="p-4 sm:p-5 rounded-xl bg-card border border-border shadow-xs">
          <div className="flex items-center justify-between text-muted-foreground text-xs">
            <span>{t.totalRevenue}</span>
            <CircleDollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="font-serif text-2xl sm:text-3xl font-bold text-primary mt-2">
            ₹{totalRevenue.toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-muted-foreground font-medium">Settled via escrow</span>
        </div>
      </div>

      {/* Tab navigation */}
      <div className="flex items-center gap-2 border-b border-border overflow-x-auto pb-px">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2.5 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors ${
            activeTab === 'overview'
              ? 'border-primary text-primary font-bold'
              : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          {t.overview}
        </button>

        {workspace === 'provider' && (
          <button
            onClick={() => setActiveTab('resources')}
            className={`px-4 py-2.5 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'resources'
                ? 'border-primary text-primary font-bold'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            <span>{t.myResources}</span>
            <span className="px-1.5 py-0.2 rounded-full bg-muted text-[10px]">{resources.length}</span>
          </button>
        )}

        <button
          onClick={() => setActiveTab('bookings')}
          className={`px-4 py-2.5 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'bookings'
              ? 'border-primary text-primary font-bold'
              : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          <span>{workspace === 'provider' ? t.bookings : t.myBookings}</span>
          <span className="px-1.5 py-0.2 rounded-full bg-muted text-[10px]">{bookings.length}</span>
        </button>

        <button
          onClick={() => setActiveTab('negotiations')}
          className={`px-4 py-2.5 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'negotiations'
              ? 'border-primary text-primary font-bold'
              : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          <span>{t.negotiations}</span>
          <span className="px-1.5 py-0.2 rounded-full bg-muted text-[10px]">{negotiations.length}</span>
        </button>

        <button
          onClick={() => setActiveTab('audits')}
          className={`px-4 py-2.5 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'audits'
              ? 'border-primary text-primary font-bold'
              : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          <span>{t.audits}</span>
          <span className="px-1.5 py-0.2 rounded-full bg-muted text-[10px]">{audits.length}</span>
        </button>
      </div>

      {/* Tab Panels */}
      <div className="pt-6">
        
        {/* OVERVIEW TAB */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Recent activity card */}
              <div className="lg:col-span-2 rounded-xl border border-border bg-card p-5 shadow-xs">
                <h3 className="font-serif font-bold text-base text-foreground mb-4">
                  Recent Booking & Rental Operations
                </h3>
                <div className="divide-y divide-border">
                  {bookings.map((b) => (
                    <div key={b.id} className="py-3.5 flex items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center font-bold">
                          {b.id.slice(-2)}
                        </div>
                        <div>
                          <h4 className="font-bold text-foreground">{b.resourceName}</h4>
                          <p className="text-muted-foreground">{b.provider} · {b.dateFrom} to {b.dateUntil}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="font-serif font-bold text-foreground block">
                          ₹{b.total.toLocaleString('en-IN')}
                        </span>
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400">
                          <CheckCircle2 className="w-2.5 h-2.5" />
                          {b.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Quick Health & Performance */}
              <div className="rounded-xl border border-border bg-card p-5 shadow-xs space-y-4">
                <h3 className="font-serif font-bold text-base text-foreground">
                  Performance & Assurance
                </h3>

                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">{t.utilizationRate}:</span>
                    <span className="font-bold text-foreground">78%</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2 overflow-hidden">
                    <div className="bg-primary h-full rounded-full" style={{ width: '78%' }} />
                  </div>
                </div>

                <div className="pt-3 border-t border-border space-y-2 text-xs">
                  <div className="flex items-center gap-2 text-foreground font-semibold">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Audit Score: 100% verified</span>
                  </div>
                  <p className="text-muted-foreground text-[11px] leading-relaxed">
                    All transactions include pre/post rental photo check-ins and escrow deposit protection.
                  </p>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* MY RESOURCES TAB */}
        {activeTab === 'resources' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-sm font-bold text-foreground">
                {t.myResources} ({resources.length})
              </h3>
              <button
                onClick={onOpenListModal}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-primary text-primary-foreground hover:bg-[#133c32]"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{t.addListing}</span>
              </button>
            </div>

            <div className="overflow-x-auto rounded-xl border border-border bg-card">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-border bg-muted/40 text-muted-foreground font-bold">
                    <th className="p-3.5">Resource</th>
                    <th className="p-3.5">Category</th>
                    <th className="p-3.5">Price / Unit</th>
                    <th className="p-3.5">Rentals</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5 text-right">Toggle Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {resources.map((r) => (
                    <tr key={r.id} className="hover:bg-muted/20">
                      <td className="p-3.5 flex items-center gap-3">
                        <img src={r.image} alt={r.name} className="w-12 h-10 object-cover rounded-md" />
                        <div>
                          <div className="font-bold text-foreground">{r.name}</div>
                          <div className="text-[11px] text-muted-foreground">{r.city} · {r.quantity} unit(s)</div>
                        </div>
                      </td>
                      <td className="p-3.5 capitalize font-medium text-foreground">
                        {(t as any)[r.category] || r.category}
                      </td>
                      <td className="p-3.5 font-bold text-foreground">
                        ₹{r.price.toLocaleString('en-IN')} / {r.unit}
                      </td>
                      <td className="p-3.5 text-muted-foreground font-medium">
                        {r.rentals} completed
                      </td>
                      <td className="p-3.5">
                        <span className={`px-2 py-0.5 rounded-sm text-[10px] font-bold ${
                          r.status === 'available'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        }`}>
                          {r.status}
                        </span>
                      </td>
                      <td className="p-3.5 text-right">
                        <button
                          onClick={() => onToggleResourceStatus(r.id)}
                          className="px-2.5 py-1 text-[11px] font-semibold rounded border border-border hover:bg-muted text-foreground"
                        >
                          {r.status === 'available' ? 'Mark Reserved' : 'Mark Available'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* BOOKINGS TAB */}
        {activeTab === 'bookings' && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-foreground">
              {workspace === 'provider' ? 'Active & Upcoming Bookings' : 'My Rental Requests'} ({bookings.length})
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {bookings.map((b) => (
                <div key={b.id} className="p-5 rounded-xl border border-border bg-card shadow-xs space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-muted text-foreground">
                        {b.id}
                      </span>
                      <h4 className="font-serif font-bold text-base text-foreground mt-1.5">{b.resourceName}</h4>
                      <p className="text-xs text-muted-foreground">{b.provider} · {b.city}</p>
                    </div>

                    <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                      {b.status}
                    </span>
                  </div>

                  <div className="p-3 bg-muted/40 rounded-lg text-xs space-y-1.5">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">{t.dates}:</span>
                      <span className="font-semibold text-foreground">{b.dateFrom} → {b.dateUntil}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">{t.quantity}:</span>
                      <span className="font-semibold text-foreground">{b.quantity} unit</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">{t.delivery}:</span>
                      <span className="font-semibold text-foreground capitalize">{b.logistics}</span>
                    </div>
                    <div className="flex justify-between pt-1 border-t border-border/80">
                      <span className="font-bold text-foreground">{t.total}:</span>
                      <span className="font-serif font-bold text-sm text-primary">₹{b.total.toLocaleString('en-IN')}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                    <span>Payment: {b.paymentMethod.toUpperCase()}</span>
                    <span>Booked on: {b.createdAt}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* NEGOTIATIONS TAB */}
        {activeTab === 'negotiations' && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-foreground">
              {t.negotiations} ({negotiations.length})
            </h3>

            {negotiations.length === 0 ? (
              <div className="p-12 text-center text-muted-foreground bg-card rounded-xl border border-border">
                {t.emptyOffers}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {negotiations.map((neg) => (
                  <div key={neg.id} className="p-5 rounded-xl border border-border bg-card shadow-xs space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-muted text-foreground">
                          {neg.id}
                        </span>
                        <h4 className="font-serif font-bold text-base text-foreground mt-1.5">{neg.resourceName}</h4>
                        <p className="text-xs text-muted-foreground">By {neg.seekerName} → {neg.provider}</p>
                      </div>

                      <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                        neg.status === 'accepted'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : neg.status === 'countered'
                          ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                      }`}>
                        {neg.status}
                      </span>
                    </div>

                    {/* Price Offer Card */}
                    <div className="grid grid-cols-2 gap-2 p-3 bg-muted/40 rounded-lg text-xs">
                      <div>
                        <span className="text-muted-foreground block">{t.listedPrice}</span>
                        <span className="font-serif font-bold line-through text-muted-foreground">
                          ₹{neg.originalPrice.toLocaleString('en-IN')}
                        </span>
                      </div>
                      <div>
                        <span className="text-primary font-bold block">{t.proposed}</span>
                        <span className="font-serif font-bold text-base text-foreground">
                          ₹{neg.proposedPrice.toLocaleString('en-IN')}
                        </span>
                      </div>
                      {neg.counterPrice && (
                        <div className="col-span-2 pt-1 border-t border-border/80 text-blue-600 dark:text-blue-400 font-semibold">
                          Counter Offer: ₹{neg.counterPrice.toLocaleString('en-IN')}
                        </div>
                      )}
                    </div>

                    <p className="text-xs text-foreground/90 italic bg-card p-2 rounded border border-border/60">
                      "{neg.message}"
                    </p>

                    {/* Action buttons */}
                    {neg.status === 'pending' && (
                      <div className="flex items-center gap-2 pt-2 border-t border-border">
                        <button
                          onClick={() => onAcceptOffer(neg.id)}
                          className="flex-1 py-1.5 bg-emerald-600 text-white text-xs font-semibold rounded hover:bg-emerald-700 transition-colors"
                        >
                          {t.accept}
                        </button>
                        <button
                          onClick={() => openCounterDialog(neg)}
                          className="flex-1 py-1.5 border border-border text-foreground text-xs font-semibold rounded hover:bg-muted transition-colors"
                        >
                          {t.counter}
                        </button>
                        <button
                          onClick={() => onRejectOffer(neg.id)}
                          className="px-3 py-1.5 text-rose-600 text-xs font-semibold rounded hover:bg-rose-50 dark:hover:bg-rose-950 transition-colors"
                        >
                          {t.reject}
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* AUDITS TAB */}
        {activeTab === 'audits' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-sm font-bold text-foreground">
                  {t.audits} (Condition Verification)
                </h3>
                <p className="text-xs text-muted-foreground">
                  Timestamped condition photos to protect security deposits and eliminate dispute claims.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {audits.map((a) => (
                <div key={a.id} className="p-5 rounded-xl border border-border bg-card shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-muted text-foreground">
                        {a.id}
                      </span>
                      <h4 className="font-serif font-bold text-sm text-foreground mt-1">{a.resourceName}</h4>
                      <p className="text-xs text-muted-foreground">{a.renter} · {a.date}</p>
                    </div>

                    <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                      {a.status}
                    </span>
                  </div>

                  {/* Photo comparison */}
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="font-semibold block mb-1 text-muted-foreground">{t.before}</span>
                      <div className="aspect-[4/3] rounded-lg overflow-hidden bg-muted">
                        <img src={a.beforePhotos[0]} alt="Before rental condition" className="w-full h-full object-cover" />
                      </div>
                    </div>

                    <div>
                      <span className="font-semibold block mb-1 text-muted-foreground">{t.after}</span>
                      <div className="aspect-[4/3] rounded-lg overflow-hidden bg-muted">
                        <img src={a.afterPhotos[0]} alt="After rental return condition" className="w-full h-full object-cover" />
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-muted-foreground bg-muted/40 p-2.5 rounded-lg border border-border/60">
                    <span className="font-semibold text-foreground">Audit notes: </span>
                    {a.notes}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>

      {/* Counter Offer Modal */}
      {counterModalOpen && activeOfferToCounter && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-card w-full max-w-sm rounded-xl border border-border p-6 shadow-xl relative animate-in fade-in zoom-in-95">
            <h3 className="font-serif font-bold text-lg text-foreground mb-1">{t.sendCounter}</h3>
            <p className="text-xs text-muted-foreground mb-4">
              {activeOfferToCounter.resourceName} (Listed: ₹{activeOfferToCounter.originalPrice})
            </p>

            <form onSubmit={submitCounter} className="space-y-4">
              <div className="space-y-1">
                <label className="block text-xs font-bold text-foreground">
                  Counter Price (₹)
                </label>
                <input
                  type="number"
                  step="250"
                  required
                  value={counterPriceInput}
                  onChange={(e) => setCounterPriceInput(Number(e.target.value))}
                  className="w-full px-3 py-2 text-sm bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setCounterModalOpen(false)}
                  className="px-3 py-1.5 text-xs font-semibold rounded border border-border text-foreground hover:bg-muted"
                >
                  {t.close}
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold rounded bg-primary text-primary-foreground hover:bg-[#133c32]"
                >
                  {t.sendCounter}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
