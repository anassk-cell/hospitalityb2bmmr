import React from 'react';
import { ShieldCheck, Heart, Sparkles } from 'lucide-react';
import { Language, ActiveTab, CategoryKey } from '../types';
import { translations } from '../data/translations';

interface FooterProps {
  lang: Language;
  onSelectTab: (tab: ActiveTab) => void;
  onSelectCategory: (cat: CategoryKey) => void;
  onOpenListModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  lang,
  onSelectTab,
  onSelectCategory,
  onOpenListModal,
}) => {
  const t = translations[lang];

  return (
    <footer className="bg-card border-t border-border mt-16 text-xs text-muted-foreground transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8 lg:gap-12">
          
          {/* Brand Column */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-primary text-primary-foreground flex items-center justify-center font-serif text-lg font-bold">
                H
              </div>
              <span className="font-serif text-lg font-bold text-foreground">
                HospitalityHub
              </span>
            </div>

            <p className="text-muted-foreground leading-relaxed max-w-sm">
              {t.footerText} Verified peer-to-peer resource sharing for hoteliers, banquets, event managers, and commercial caterers.
            </p>

            <div className="flex items-center gap-2 text-[11px] text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 p-2.5 rounded-lg border border-emerald-200/50 w-fit">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Certified B2B Enterprise Exchange Network</span>
            </div>
          </div>

          {/* Marketplace Column */}
          <div className="space-y-3">
            <h4 className="font-bold text-foreground text-xs uppercase tracking-wider">
              {t.marketplace}
            </h4>
            <ul className="space-y-2">
              <li>
                <button 
                  onClick={() => {
                    onSelectCategory('spaces');
                    onSelectTab('marketplace');
                  }} 
                  className="hover:text-foreground transition-colors"
                >
                  {t.spaces}
                </button>
              </li>
              <li>
                <button 
                  onClick={() => {
                    onSelectCategory('kitchen');
                    onSelectTab('marketplace');
                  }} 
                  className="hover:text-foreground transition-colors"
                >
                  {t.kitchen}
                </button>
              </li>
              <li>
                <button 
                  onClick={() => {
                    onSelectCategory('vehicles');
                    onSelectTab('marketplace');
                  }} 
                  className="hover:text-foreground transition-colors"
                >
                  {t.vehicles}
                </button>
              </li>
              <li>
                <button 
                  onClick={() => {
                    onSelectCategory('av');
                    onSelectTab('marketplace');
                  }} 
                  className="hover:text-foreground transition-colors"
                >
                  {t.av}
                </button>
              </li>
              <li>
                <button 
                  onClick={() => {
                    onSelectCategory('cold');
                    onSelectTab('marketplace');
                  }} 
                  className="hover:text-foreground transition-colors"
                >
                  {t.cold}
                </button>
              </li>
            </ul>
          </div>

          {/* Business Column */}
          <div className="space-y-3">
            <h4 className="font-bold text-foreground text-xs uppercase tracking-wider">
              {t.business}
            </h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => onSelectTab('providers')} className="hover:text-foreground transition-colors">
                  {t.providers}
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('how')} className="hover:text-foreground transition-colors">
                  {t.how}
                </button>
              </li>
              <li>
                <button onClick={onOpenListModal} className="hover:text-foreground transition-colors text-primary font-semibold">
                  {t.list}
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('dashboard')} className="hover:text-foreground transition-colors">
                  {t.dashboard}
                </button>
              </li>
            </ul>
          </div>

          {/* Support & Legal Column */}
          <div className="space-y-3">
            <h4 className="font-bold text-foreground text-xs uppercase tracking-wider">
              {t.support}
            </h4>
            <ul className="space-y-2">
              <li>
                <span className="hover:text-foreground transition-colors cursor-pointer">{t.help}</span>
              </li>
              <li>
                <span className="hover:text-foreground transition-colors cursor-pointer">{t.faqs}</span>
              </li>
              <li>
                <span className="hover:text-foreground transition-colors cursor-pointer">{t.privacy}</span>
              </li>
              <li>
                <span className="hover:text-foreground transition-colors cursor-pointer">{t.terms}</span>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom copyright row */}
        <div className="mt-12 pt-6 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px]">
          <div>
            © {new Date().getFullYear()} {t.copyright}
          </div>
          <div className="flex items-center gap-4">
            <span className="text-muted-foreground">{t.trusted}</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
