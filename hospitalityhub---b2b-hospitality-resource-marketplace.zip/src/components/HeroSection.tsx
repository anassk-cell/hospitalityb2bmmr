import React from 'react';
import { ShieldCheck, CircleDollarSign, CalendarRange, ArrowRight, Sparkles, Building, CheckCircle2 } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../data/translations';

interface HeroSectionProps {
  lang: Language;
  onExploreClick: () => void;
  onListClick: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  lang,
  onExploreClick,
  onListClick,
}) => {
  const t = translations[lang];

  return (
    <section className="relative overflow-hidden bg-[#102e26] text-white py-16 sm:py-24 border-b border-[#1c4d40]">
      {/* Background imagery with luxury gradient overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="/assets/hospitality-hero-DaY1D21i.jpg"
          alt="Hospitality interior"
          className="w-full h-full object-cover opacity-20 filter brightness-75 scale-105 transform motion-safe:transition-transform duration-1000"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0d261f] via-[#102e26]/90 to-[#102e26]/70" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(60,184,143,0.15),transparent_60%)]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl">
          
          {/* Eyebrow badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#1b4b3e]/80 border border-[#2d7360]/50 text-xs font-semibold tracking-wider text-[#9be8d0] uppercase mb-6 backdrop-blur-xs">
            <Sparkles className="w-3.5 h-3.5 text-[#e5c278]" />
            <span>{t.eyebrow}</span>
          </div>

          {/* Editorial Title */}
          <h1 className="font-serif text-3xl sm:text-5xl lg:text-6xl font-normal tracking-tight text-[#fbf9f6] leading-[1.12] mb-6">
            {t.heroTitle}
          </h1>

          {/* Subtitle */}
          <p className="text-base sm:text-lg text-[#d0dfd9] leading-relaxed mb-8 max-w-2xl font-light">
            {t.heroText}
          </p>

          {/* Action CTAs */}
          <div className="flex flex-wrap items-center gap-3 sm:gap-4 mb-10">
            <button
              onClick={onExploreClick}
              className="inline-flex items-center gap-2 px-6 py-3.5 rounded-lg bg-[#3cb88f] text-[#081d16] font-semibold text-sm sm:text-base hover:bg-[#4dd0a4] transition-all shadow-lg shadow-[#3cb88f]/20 active:scale-95"
            >
              <span>{t.explore}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={onListClick}
              className="inline-flex items-center gap-2 px-6 py-3.5 rounded-lg bg-white/10 hover:bg-white/15 text-[#fbf9f6] border border-white/20 font-semibold text-sm sm:text-base backdrop-blur-xs transition-all active:scale-95"
            >
              <span>{t.listYours}</span>
            </button>
          </div>

          {/* Trust Value Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-6 border-t border-white/10 text-xs sm:text-sm text-[#c4dbd3]">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#4dd0a4] shrink-0" />
              <span>{t.verifiedBusinesses}</span>
            </div>
            <div className="flex items-center gap-2">
              <CircleDollarSign className="w-4 h-4 text-[#e5c278] shrink-0" />
              <span>{t.transparentPricing}</span>
            </div>
            <div className="flex items-center gap-2 col-span-2 sm:col-span-1">
              <CalendarRange className="w-4 h-4 text-[#4dd0a4] shrink-0" />
              <span>{t.calendarAvailability}</span>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
