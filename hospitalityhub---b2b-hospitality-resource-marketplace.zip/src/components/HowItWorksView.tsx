import React from 'react';
import { 
  Search, 
  Handshake, 
  CalendarCheck, 
  ShieldCheck, 
  Sparkles, 
  CircleDollarSign, 
  Lock, 
  Calendar, 
  Building, 
  ArrowRight 
} from 'lucide-react';
import { Language } from '../types';
import { translations } from '../data/translations';

interface HowItWorksViewProps {
  lang: Language;
  onExploreClick: () => void;
  onListClick: () => void;
}

export const HowItWorksView: React.FC<HowItWorksViewProps> = ({
  lang,
  onExploreClick,
  onListClick,
}) => {
  const t = translations[lang];

  return (
    <div className="w-full">
      {/* Hero header */}
      <section className="bg-muted/40 py-16 sm:py-20 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center max-w-3xl">
          <span className="text-xs font-bold uppercase tracking-wider text-primary">
            {t.how}
          </span>
          <h1 className="font-serif text-3xl sm:text-5xl font-bold text-foreground mt-2 mb-4 leading-tight">
            {t.process}
          </h1>
          <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
            Eliminate idle days on commercial kitchen equipment, banquet furniture, event production stages, and luxury hospitality vehicles.
          </p>
        </div>
      </section>

      {/* 3 Step Workflow */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          
          {/* Step 1 */}
          <div className="bg-card rounded-2xl border border-border p-8 shadow-xs relative space-y-4">
            <div className="font-serif text-4xl sm:text-5xl font-bold text-primary/30">
              01
            </div>
            <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
              <Search className="w-6 h-6" />
            </div>
            <h3 className="font-serif text-xl font-bold text-foreground">
              {t.step1}
            </h3>
            <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
              {t.step1Text} Filter by location in Mumbai MMR, capacity requirements, dates, and whether your need is planned or emergency relief.
            </p>
          </div>

          {/* Step 2 */}
          <div className="bg-card rounded-2xl border border-border p-8 shadow-xs relative space-y-4">
            <div className="font-serif text-4xl sm:text-5xl font-bold text-primary/30">
              02
            </div>
            <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
              <Handshake className="w-6 h-6" />
            </div>
            <h3 className="font-serif text-xl font-bold text-foreground">
              {t.step2}
            </h3>
            <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
              {t.step2Text} Propose custom terms, multi-day discounts, delivery logistics preferences, and communicate directly with decision-makers.
            </p>
          </div>

          {/* Step 3 */}
          <div className="bg-card rounded-2xl border border-border p-8 shadow-xs relative space-y-4">
            <div className="font-serif text-4xl sm:text-5xl font-bold text-primary/30">
              03
            </div>
            <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
              <CalendarCheck className="w-6 h-6" />
            </div>
            <h3 className="font-serif text-xl font-bold text-foreground">
              {t.step3}
            </h3>
            <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
              {t.step3Text} Instant calendar locking, automated rental agreements, check-in photo audit records, and secure escrow handling.
            </p>
          </div>

        </div>
      </section>

      {/* Trust & Value Proposition Grid matching reference */}
      <section className="bg-muted/40 py-16 sm:py-20 border-y border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              {t.verifiedBusinesses}
            </span>
            <h2 className="font-serif text-2xl sm:text-4xl font-bold text-foreground mt-2">
              {t.trustTitle}
            </h2>
            <p className="text-xs sm:text-sm text-muted-foreground mt-2">
              {t.trustSub}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="p-6 rounded-xl bg-card border border-border shadow-xs space-y-2.5">
              <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400 flex items-center justify-center">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="font-serif font-bold text-base text-foreground">{t.verifiedBusinesses}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Every business provider is verified with valid hospitality registration, GSTIN verification, and hygiene audit proofs.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-card border border-border shadow-xs space-y-2.5">
              <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                <Sparkles className="w-5 h-5" />
              </div>
              <h3 className="font-serif font-bold text-base text-foreground">{t.smartMatching}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Algorithmic suitability scoring factoring in distance, immediate calendar availability, and commercial kitchen/venue ratings.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-card border border-border shadow-xs space-y-2.5">
              <div className="w-10 h-10 rounded-lg bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400 flex items-center justify-center">
                <Calendar className="w-5 h-5" />
              </div>
              <h3 className="font-serif font-bold text-base text-foreground">{t.flexibleBooking}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Reserve months in advance for banquets or tap emergency same-day backup when kitchen equipment or power generators fail.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-card border border-border shadow-xs space-y-2.5">
              <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                <CircleDollarSign className="w-5 h-5" />
              </div>
              <h3 className="font-serif font-bold text-base text-foreground">{t.transparentPricing}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                No hidden broker commissions or middleman markups. Direct business quotes with itemized refundable deposits.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-card border border-border shadow-xs space-y-2.5">
              <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400 flex items-center justify-center">
                <CalendarCheck className="w-5 h-5" />
              </div>
              <h3 className="font-serif font-bold text-base text-foreground">{t.calendarAvailability}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Live locked calendars prevent double booking. Real-time updates ensure only truly open assets are requested.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-card border border-border shadow-xs space-y-2.5">
              <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                <Lock className="w-5 h-5" />
              </div>
              <h3 className="font-serif font-bold text-base text-foreground">{t.secureTransactions}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Mandatory before-and-after photo audits guarantee condition verification and hassle-free security deposit clearance.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA section matching reference */}
      <section className="bg-primary text-primary-foreground py-16 sm:py-20">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <span className="text-xs uppercase font-bold tracking-widest text-[#9be8d0]">
            {t.providerView}
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-normal text-white">
            {t.ctaTitle}
          </h2>
          <p className="text-sm sm:text-base text-[#d0dfd9] max-w-xl mx-auto font-light">
            {t.ctaText}
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
            <button
              onClick={onListClick}
              className="px-6 py-3 rounded-lg bg-white text-primary font-bold text-sm hover:bg-neutral-100 transition-colors shadow-lg shadow-black/10 active:scale-95"
            >
              {t.listYours}
            </button>
            <button
              onClick={onExploreClick}
              className="px-6 py-3 rounded-lg bg-white/10 hover:bg-white/15 text-white border border-white/20 font-bold text-sm backdrop-blur-xs transition-colors active:scale-95"
            >
              {t.explore}
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
