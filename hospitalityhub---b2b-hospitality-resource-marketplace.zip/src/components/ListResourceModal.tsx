import React, { useState, useRef } from 'react';
import { 
  X, 
  Upload, 
  Plus, 
  Image as ImageIcon, 
  Trash2, 
  Star, 
  ChevronLeft, 
  ChevronRight, 
  CheckCircle2, 
  Sparkles,
  Building 
} from 'lucide-react';
import { CategoryKey, BookingType, Resource, Language } from '../types';
import { CATEGORIES } from '../data/mockData';
import { translations } from '../data/translations';

interface ListResourceModalProps {
  lang: Language;
  onClose: () => void;
  onAddResource: (newResource: Resource) => void;
}

interface UploadedPhoto {
  id: string;
  url: string;
  name: string;
}

export const ListResourceModal: React.FC<ListResourceModalProps> = ({
  lang,
  onClose,
  onAddResource,
}) => {
  const t = translations[lang];
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form fields
  const [name, setName] = useState('');
  const [provider, setProvider] = useState('The Meridian Hospitality Group');
  const [city, setCity] = useState('Mumbai');
  const [category, setCategory] = useState<CategoryKey>('spaces');
  const [price, setPrice] = useState<number>(15000);
  const [unit, setUnit] = useState<'day' | 'event'>('day');
  const [quantity, setQuantity] = useState<number>(1);
  const [bookingType, setBookingType] = useState<BookingType>('planned');
  const [description, setDescription] = useState('');
  const [specsText, setSpecsText] = useState('Capacity: 150 guests\nAir conditioning\nOn-site parking\nDedicated support staff');

  // Photo uploads
  const [photos, setPhotos] = useState<UploadedPhoto[]>([
    {
      id: 'photo-1',
      url: '/assets/hospitality-hero-DaY1D21i.jpg',
      name: 'Main Space View'
    }
  ]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const newItems: UploadedPhoto[] = Array.from(e.target.files).map((file, i) => ({
      id: `up-${Date.now()}-${i}`,
      url: URL.createObjectURL(file),
      name: file.name
    }));
    setPhotos((prev) => [...prev, ...newItems]);
    e.target.value = '';
  };

  const movePhoto = (index: number, direction: -1 | 1) => {
    const newIndex = index + direction;
    if (newIndex < 0 || newIndex >= photos.length) return;
    const arr = [...photos];
    const [moved] = arr.splice(index, 1);
    arr.splice(newIndex, 0, moved);
    setPhotos(arr);
  };

  const setCoverPhoto = (index: number) => {
    if (index === 0) return;
    const arr = [...photos];
    const [moved] = arr.splice(index, 1);
    setPhotos([moved, ...arr]);
  };

  const removePhoto = (id: string) => {
    setPhotos((prev) => prev.filter((p) => p.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const specsArray = specsText
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean);

    const coverUrl = photos.length > 0 ? photos[0].url : '/assets/hospitality-hero-DaY1D21i.jpg';
    const allPhotoUrls = photos.map((p) => p.url);

    const newResource: Resource = {
      id: Date.now(),
      name,
      provider,
      city,
      category,
      image: coverUrl,
      price: Number(price),
      unit,
      quantity: Number(quantity),
      rating: '5.0',
      reviews: 1,
      match: 99,
      status: 'available',
      booking: bookingType,
      description: description || `${name} offered by ${provider} in ${city} for verified B2B hospitality use.`,
      specs: specsArray.length > 0 ? specsArray : ['Verified hospitality grade', 'On-site technical support', 'Flexible handover'],
      rentals: 0,
      photos: allPhotoUrls,
      deposit: Math.round(price * 0.4),
      lockedDates: [],
    };

    onAddResource(newResource);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div 
        className="bg-card w-full max-w-2xl rounded-2xl border border-border shadow-2xl overflow-hidden my-auto relative animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-border bg-muted/40">
          <div>
            <h2 className="font-serif text-xl font-bold text-foreground">
              {t.addListing}
            </h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              Turn unused hospitality capacity into high-yield revenue
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          
          {/* Resource Name */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-foreground">
              {t.resourceName} *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Executive Banquet Hall, Walk-in Freezer, 12-Seater Sprinter Van..."
              className="w-full px-3 py-2 text-xs sm:text-sm bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          {/* Provider name & City */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="block text-xs font-bold text-foreground">
                {t.businessName} *
              </label>
              <input
                type="text"
                required
                value={provider}
                onChange={(e) => setProvider(e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-bold text-foreground">
                {t.location} *
              </label>
              <select
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="Mumbai">Mumbai</option>
                <option value="Navi Mumbai">Navi Mumbai</option>
                <option value="Thane">Thane</option>
                <option value="Panvel">Panvel</option>
                <option value="Pune">Pune</option>
              </select>
            </div>
          </div>

          {/* Category & Booking type */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="block text-xs font-bold text-foreground">
                {t.category} *
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as CategoryKey)}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              >
                {CATEGORIES.filter((c) => c.key !== 'all').map((c) => (
                  <option key={c.key} value={c.key}>
                    {c.icon} {(t as any)[c.key] || c.key}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-bold text-foreground">
                {t.bookingType} *
              </label>
              <select
                value={bookingType}
                onChange={(e) => setBookingType(e.target.value as BookingType)}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="planned">▦ {t.planned}</option>
                <option value="emergency">⚡ {t.emergency}</option>
              </select>
            </div>
          </div>

          {/* Pricing & Units */}
          <div className="grid grid-cols-3 gap-3">
            <div className="space-y-1">
              <label className="block text-xs font-bold text-foreground">
                {t.price} (₹) *
              </label>
              <input
                type="number"
                min="500"
                step="500"
                required
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-bold text-foreground">
                Unit *
              </label>
              <select
                value={unit}
                onChange={(e) => setUnit(e.target.value as 'day' | 'event')}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="day">Per {t.day}</option>
                <option value="event">Per {t.eventUnit}</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-bold text-foreground">
                Units Available *
              </label>
              <input
                type="number"
                min="1"
                max="50"
                required
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
          </div>

          {/* Description */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-foreground">
              {t.description}
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe capacity, condition, equipment included, and pickup/access logistics..."
              className="w-full p-2 text-xs sm:text-sm bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          {/* Specifications (one per line) */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-foreground">
              {t.specifications} (One per line)
            </label>
            <textarea
              rows={3}
              value={specsText}
              onChange={(e) => setSpecsText(e.target.value)}
              placeholder="Enter specifications (e.g. Dimensions, power requirements, guest capacity)..."
              className="w-full p-2 text-xs sm:text-sm font-mono bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          {/* Photo Management Section matching reference */}
          <div className="space-y-2 pt-2 border-t border-border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-foreground">
                  {t.uploadTitle} <span className="font-normal text-muted-foreground">· {t.uploadHint}</span>
                </p>
              </div>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={handleFileUpload}
            />

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {/* Add photo card button */}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex flex-col items-center justify-center aspect-[4/3] rounded-lg border-2 border-dashed border-border hover:border-primary/60 bg-muted/30 hover:bg-muted/60 transition-colors p-3 text-center cursor-pointer"
              >
                <Upload className="w-5 h-5 text-muted-foreground mb-1" />
                <span className="text-[11px] font-semibold text-foreground">{t.uploadPhotos}</span>
              </button>

              {/* Uploaded photo thumbnails */}
              {photos.map((p, idx) => (
                <div key={p.id} className="relative aspect-[4/3] rounded-lg overflow-hidden border border-border group bg-muted">
                  <img src={p.url} alt={p.name} className="w-full h-full object-cover" />
                  
                  {idx === 0 && (
                    <span className="absolute top-1.5 left-1.5 px-1.5 py-0.5 rounded-sm bg-primary text-primary-foreground text-[10px] font-bold shadow-xs">
                      {t.cover}
                    </span>
                  )}

                  {/* Thumbnail controls overlay */}
                  <div className="absolute inset-x-0 bottom-0 bg-black/75 backdrop-blur-xs flex items-center justify-center gap-1 p-1 opacity-90 sm:opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      type="button"
                      disabled={idx === 0}
                      onClick={() => movePhoto(idx, -1)}
                      className="p-1 text-white hover:text-primary-foreground disabled:opacity-30"
                      title={t.moveLeft}
                    >
                      <ChevronLeft className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      disabled={idx === photos.length - 1}
                      onClick={() => movePhoto(idx, 1)}
                      className="p-1 text-white hover:text-primary-foreground disabled:opacity-30"
                      title={t.moveRight}
                    >
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                    {idx !== 0 && (
                      <button
                        type="button"
                        onClick={() => setCoverPhoto(idx)}
                        className="p-1 text-white hover:text-amber-300"
                        title={t.setCover}
                      >
                        <Star className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => removePhoto(p.id)}
                      className="p-1 text-white hover:text-rose-400"
                      title={t.remove}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <p className="text-[11px] text-muted-foreground italic">
              {t.photoUploadOnly}
            </p>
          </div>

          {/* Submit button */}
          <div className="pt-4 border-t border-border flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="py-2.5 px-4 text-xs font-semibold rounded-lg border border-border text-foreground hover:bg-muted"
            >
              {t.close}
            </button>
            <button
              type="submit"
              className="py-2.5 px-6 text-xs font-semibold rounded-lg bg-primary text-primary-foreground hover:bg-[#133c32] shadow-md transition-all flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>{t.createListing}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
