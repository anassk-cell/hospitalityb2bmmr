import React, { useState } from 'react';
import { 
  Building2, 
  PlusCircle, 
  LayoutDashboard, 
  Heart, 
  Menu, 
  X, 
  Sun, 
  Moon, 
  Languages, 
  UserCheck, 
  Bell,
  Sparkles
} from 'lucide-react';
import { Language, ActiveTab } from '../types';
import { translations } from '../data/translations';

interface NavbarProps {
  lang: Language;
  onToggleLang: () => void;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  onOpenListModal: () => void;
  savedCount: number;
  showSavedOnly: boolean;
  onToggleSavedOnly: () => void;
  notificationCount: number;
  onOpenNotifications: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  lang,
  onToggleLang,
  theme,
  onToggleTheme,
  activeTab,
  onSelectTab,
  onOpenListModal,
  savedCount,
  showSavedOnly,
  onToggleSavedOnly,
  notificationCount,
  onOpenNotifications,
}) => {
  const t = translations[lang];
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);

  const handleNavClick = (tab: ActiveTab) => {
    onSelectTab(tab);
    setMobileMenuOpen(false);
  };

  return (
    <>
      {/* Top micro-announcement bar */}
      <aside aria-label="Announcement" className="w-full bg-[#133c32] text-[#e8f3ee] text-xs py-1.5 px-4 text-center font-medium border-b border-[#1b4b3f] flex items-center justify-center gap-2">
        <Sparkles className="w-3.5 h-3.5 text-[#e5c278] shrink-0" />
        <span>{t.trusted}</span>
      </aside>

      {/* Main sticky navigation */}
      <header className="sticky top-0 z-40 w-full bg-card/95 backdrop-blur-md border-b border-border shadow-xs transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-18">
            
            {/* Logo */}
            <div className="flex items-center gap-8">
              <button 
                onClick={() => handleNavClick('marketplace')}
                className="group flex items-center gap-2.5 text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-primary rounded-md"
              >
                <div className="w-9 h-9 rounded-lg bg-primary text-primary-foreground flex items-center justify-center font-serif text-xl font-bold shadow-xs group-hover:scale-105 transition-transform">
                  H
                </div>
                <div>
                  <div className="font-serif text-lg sm:text-xl font-bold tracking-tight text-foreground flex items-center gap-1.5">
                    HospitalityHub
                    <span className="text-primary text-xs font-sans font-semibold px-1.5 py-0.5 rounded-sm bg-primary/10 border border-primary/20">
                      B2B
                    </span>
                  </div>
                </div>
              </button>

              {/* Desktop Nav Links */}
              <nav className="hidden md:flex items-center gap-1">
                <button
                  onClick={() => handleNavClick('marketplace')}
                  className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                    activeTab === 'marketplace'
                      ? 'text-primary bg-primary/10 font-semibold'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted/70'
                  }`}
                >
                  {t.marketplace}
                </button>
                <button
                  onClick={() => handleNavClick('resources')}
                  className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                    activeTab === 'resources'
                      ? 'text-primary bg-primary/10 font-semibold'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted/70'
                  }`}
                >
                  {t.resources}
                </button>
                <button
                  onClick={() => handleNavClick('providers')}
                  className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                    activeTab === 'providers'
                      ? 'text-primary bg-primary/10 font-semibold'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted/70'
                  }`}
                >
                  {t.providers}
                </button>
                <button
                  onClick={() => handleNavClick('how')}
                  className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                    activeTab === 'how'
                      ? 'text-primary bg-primary/10 font-semibold'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted/70'
                  }`}
                >
                  {t.how}
                </button>
              </nav>
            </div>

            {/* Right action controls */}
            <div className="flex items-center gap-2 sm:gap-3">
              
              {/* Language Switcher */}
              <button
                onClick={onToggleLang}
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-md border border-border bg-card text-foreground hover:bg-muted transition-colors"
                title="Switch Language / भाषा बदलें"
                aria-label="Toggle language"
              >
                <Languages className="w-3.5 h-3.5 text-primary" />
                <span>{lang === 'en' ? 'EN / हिं' : 'हिं / EN'}</span>
              </button>

              {/* Theme toggle */}
              <button
                onClick={onToggleTheme}
                className="p-2 text-muted-foreground hover:text-foreground rounded-md hover:bg-muted transition-colors"
                title={theme === 'light' ? t.dark : t.light}
                aria-label="Toggle theme"
              >
                {theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4 text-amber-400" />}
              </button>

              {/* Saved items filter button */}
              <button
                onClick={onToggleSavedOnly}
                className={`relative p-2 rounded-md transition-colors ${
                  showSavedOnly 
                    ? 'bg-rose-50 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400' 
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                }`}
                title={t.saved}
                aria-label={t.saved}
              >
                <Heart className={`w-4 h-4 ${showSavedOnly || savedCount > 0 ? 'fill-current' : ''}`} />
                {savedCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                    {savedCount}
                  </span>
                )}
              </button>

              {/* Notification icon */}
              <button
                onClick={onOpenNotifications}
                className="relative p-2 text-muted-foreground hover:text-foreground rounded-md hover:bg-muted transition-colors"
                title={t.notifications}
                aria-label={t.notifications}
              >
                <Bell className="w-4 h-4" />
                {notificationCount > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                )}
              </button>

              {/* Dashboard Button */}
              <button
                onClick={() => handleNavClick('dashboard')}
                className={`hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md border transition-colors ${
                  activeTab === 'dashboard'
                    ? 'bg-primary text-primary-foreground border-primary'
                    : 'border-border bg-card text-foreground hover:bg-muted'
                }`}
              >
                <LayoutDashboard className="w-3.5 h-3.5" />
                <span>{t.dashboard}</span>
              </button>

              {/* List a Resource CTA */}
              <button
                onClick={onOpenListModal}
                className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-md bg-primary text-primary-foreground hover:bg-[#133d32] shadow-xs transition-all active:scale-95"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>{t.list}</span>
              </button>

              {/* Profile icon */}
              <button
                onClick={() => setShowProfileModal(true)}
                className="p-1.5 text-muted-foreground hover:text-foreground rounded-full hover:bg-muted transition-colors"
                title={t.login}
                aria-label="Profile"
              >
                <div className="w-7 h-7 rounded-full bg-secondary text-secondary-foreground flex items-center justify-center text-xs font-bold border border-border">
                  <UserCheck className="w-3.5 h-3.5" />
                </div>
              </button>

              {/* Mobile menu trigger */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden p-2 text-muted-foreground hover:text-foreground rounded-md hover:bg-muted transition-colors"
                aria-label={mobileMenuOpen ? t.close : t.menu}
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-border bg-card px-4 pt-3 pb-5 space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => handleNavClick('marketplace')}
                className={`px-3 py-2 text-sm font-medium rounded-md text-left ${
                  activeTab === 'marketplace' ? 'bg-primary/10 text-primary font-semibold' : 'text-muted-foreground'
                }`}
              >
                {t.marketplace}
              </button>
              <button
                onClick={() => handleNavClick('resources')}
                className={`px-3 py-2 text-sm font-medium rounded-md text-left ${
                  activeTab === 'resources' ? 'bg-primary/10 text-primary font-semibold' : 'text-muted-foreground'
                }`}
              >
                {t.resources}
              </button>
              <button
                onClick={() => handleNavClick('providers')}
                className={`px-3 py-2 text-sm font-medium rounded-md text-left ${
                  activeTab === 'providers' ? 'bg-primary/10 text-primary font-semibold' : 'text-muted-foreground'
                }`}
              >
                {t.providers}
              </button>
              <button
                onClick={() => handleNavClick('how')}
                className={`px-3 py-2 text-sm font-medium rounded-md text-left ${
                  activeTab === 'how' ? 'bg-primary/10 text-primary font-semibold' : 'text-muted-foreground'
                }`}
              >
                {t.how}
              </button>
            </div>

            <div className="pt-2 border-t border-border flex flex-col gap-2">
              <button
                onClick={() => handleNavClick('dashboard')}
                className="w-full flex items-center justify-center gap-2 py-2 text-xs font-semibold rounded-md border border-border bg-card text-foreground"
              >
                <LayoutDashboard className="w-4 h-4 text-primary" />
                {t.dashboard}
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenListModal();
                }}
                className="w-full flex items-center justify-center gap-2 py-2.5 text-xs font-semibold rounded-md bg-primary text-primary-foreground shadow-xs"
              >
                <PlusCircle className="w-4 h-4" />
                {t.list}
              </button>
            </div>
          </div>
        )}
      </header>

      {/* Demo Profile Modal */}
      {showProfileModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4">
          <div className="bg-card w-full max-w-sm rounded-xl border border-border p-6 shadow-xl relative animate-in fade-in zoom-in-95 duration-200">
            <button
              onClick={() => setShowProfileModal(false)}
              className="absolute top-4 right-4 p-1 rounded-md text-muted-foreground hover:text-foreground"
            >
              <X className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-lg">
                H
              </div>
              <div>
                <h3 className="font-serif font-bold text-lg text-foreground">{t.profileTitle}</h3>
                <p className="text-xs text-muted-foreground">demo-partner@hospitalityhub.in</p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed mb-5">
              {t.profileText}
            </p>
            <div className="p-3 bg-muted rounded-lg border border-border text-xs space-y-1.5 mb-5">
              <div className="flex justify-between">
                <span className="text-muted-foreground">{t.status}:</span>
                <span className="font-semibold text-emerald-600 dark:text-emerald-400">Verified Business Partner</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Region:</span>
                <span className="font-semibold">Mumbai MMR</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">GSTIN:</span>
                <span className="font-mono text-[11px]">27AAACH7409R1ZZ</span>
              </div>
            </div>
            <button
              onClick={() => setShowProfileModal(false)}
              className="w-full py-2 bg-primary text-primary-foreground text-xs font-semibold rounded-md hover:bg-primary/90 transition-colors"
            >
              {t.closeDialog}
            </button>
          </div>
        </div>
      )}
    </>
  );
};
