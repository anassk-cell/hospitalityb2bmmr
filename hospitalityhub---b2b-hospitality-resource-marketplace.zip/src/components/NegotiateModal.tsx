import React, { useState } from 'react';
import { 
  X, 
  Send, 
  CheckCircle2, 
  CircleDollarSign, 
  Calendar, 
  Building2, 
  MessageSquare,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { Resource, NegotiationOffer, Language } from '../types';
import { translations } from '../data/translations';

interface NegotiateModalProps {
  resource: Resource | null;
  lang: Language;
  onClose: () => void;
  onSubmitOffer: (offer: NegotiationOffer) => void;
}

export const NegotiateModal: React.FC<NegotiateModalProps> = ({
  resource,
  lang,
  onClose,
  onSubmitOffer,
}) => {
  if (!resource) return null;

  const t = translations[lang];

  const [proposedPrice, setProposedPrice] = useState(Math.round(resource.price * 0.9));
  const [dateFrom, setDateFrom] = useState(new Date().toISOString().split('T')[0]);
  const [dateUntil, setDateUntil] = useState(new Date(Date.now() + 86400000).toISOString().split('T')[0]);
  const [message, setMessage] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  const discountPercent = Math.round(((resource.price - proposedPrice) / resource.price) * 100);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const offer: NegotiationOffer = {
      id: `NEG-${Math.floor(100 + Math.random() * 900)}`,
      resourceId: resource.id,
      resourceName: resource.name,
      provider: resource.provider,
      seekerName: 'My Hospitality Enterprise',
      originalPrice: resource.price,
      proposedPrice,
      unit: resource.unit,
      dateFrom,
      dateUntil,
      message: message || 'Interested in booking for our upcoming hospitality requirement.',
      type: 'outgoing',
      status: 'pending',
      createdAt: new Date().toISOString().split('T')[0],
    };

    onSubmitOffer(offer);
    setIsSuccess(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div 
        className="bg-card w-full max-w-lg rounded-2xl border border-border shadow-2xl overflow-hidden relative animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-border bg-muted/30">
          <div>
            <h2 className="font-serif text-xl font-bold text-foreground">
              {t.offerTitle}
            </h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              {resource.name} · {resource.provider}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSuccess ? (
          <div className="p-6 sm:p-8 text-center space-y-5">
            <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400 mx-auto flex items-center justify-center shadow-md">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <h3 className="font-serif text-2xl font-bold text-foreground">
                {t.offerSent}
              </h3>
              <p className="text-xs text-muted-foreground mt-1 max-w-sm mx-auto">
                Your proposed offer of ₹{proposedPrice.toLocaleString('en-IN')} / {resource.unit === 'day' ? t.day : t.eventUnit} has been sent to {resource.provider}. You will be notified when they accept or counter.
              </p>
            </div>

            <button
              onClick={onClose}
              className="w-full py-2.5 bg-primary text-primary-foreground text-xs font-semibold rounded-lg hover:bg-primary/90 transition-colors"
            >
              {t.done}
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4">
            
            {/* Price comparison card */}
            <div className="grid grid-cols-2 gap-3 p-3.5 rounded-xl bg-muted/40 border border-border">
              <div>
                <span className="text-[11px] text-muted-foreground block">{t.listedPrice}</span>
                <span className="font-serif text-base sm:text-lg font-bold text-muted-foreground line-through">
                  ₹{resource.price.toLocaleString('en-IN')}
                </span>
                <span className="text-[10px] text-muted-foreground ml-1">/ {resource.unit === 'day' ? t.day : t.eventUnit}</span>
              </div>

              <div>
                <span className="text-[11px] text-primary font-bold block">{t.proposedPrice}</span>
                <span className="font-serif text-lg sm:text-xl font-bold text-foreground">
                  ₹{proposedPrice.toLocaleString('en-IN')}
                </span>
                {discountPercent > 0 && (
                  <span className="text-[10px] text-emerald-600 font-bold ml-1">(-{discountPercent}%)</span>
                )}
              </div>
            </div>

            {/* Proposed price input */}
            <div className="space-y-1.5">
              <label htmlFor="proposed-price-input" className="block text-xs font-bold text-foreground">
                {t.proposedPrice} (₹)
              </label>
              <div className="relative">
                <CircleDollarSign className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  id="proposed-price-input"
                  type="number"
                  min="1000"
                  step="500"
                  required
                  value={proposedPrice}
                  onChange={(e) => setProposedPrice(Number(e.target.value))}
                  className="w-full pl-9 pr-3 py-2 text-sm bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>

            {/* Dates row */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label htmlFor="neg-date-from" className="block text-xs font-bold text-foreground">{t.from}</label>
                <input
                  id="neg-date-from"
                  type="date"
                  required
                  value={dateFrom}
                  onChange={(e) => setDateFrom(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <div className="space-y-1">
                <label htmlFor="neg-date-until" className="block text-xs font-bold text-foreground">{t.until}</label>
                <input
                  id="neg-date-until"
                  type="date"
                  required
                  value={dateUntil}
                  onChange={(e) => setDateUntil(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>

            {/* Message / special terms */}
            <div className="space-y-1.5">
              <label htmlFor="neg-message-input" className="block text-xs font-bold text-foreground">
                {t.message}
              </label>
              <textarea
                id="neg-message-input"
                rows={3}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Mention multiple days discount, flexible check-in timings, or bulk requirements..."
                className="w-full p-2.5 text-xs bg-background border border-border rounded-lg text-foreground placeholder:text-muted-foreground/70 focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            <p className="text-[11px] text-muted-foreground italic">
              {resource.provider} typically responds within 2 hours during business operations.
            </p>

            <button
              type="submit"
              className="w-full py-2.5 bg-primary text-primary-foreground text-xs font-semibold rounded-lg hover:bg-[#133c32] shadow-sm transition-all flex items-center justify-center gap-2"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{t.sendOffer}</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
