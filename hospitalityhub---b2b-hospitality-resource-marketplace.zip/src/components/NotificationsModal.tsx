import React from 'react';
import { X, Bell, CheckCircle2, MessageSquare, ShieldCheck, ArrowRight } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../data/translations';

interface NotificationItem {
  id: string;
  title: string;
  desc: string;
  time: string;
  type: 'booking' | 'offer' | 'audit';
}

interface NotificationsModalProps {
  lang: Language;
  onClose: () => void;
  onViewDashboard: () => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  lang,
  onClose,
  onViewDashboard,
}) => {
  const t = translations[lang];

  const items: NotificationItem[] = [
    {
      id: 'notif-1',
      title: 'Booking Confirmed',
      desc: 'Grand Ballroom booking BK-8902 has been confirmed by The Meridian Hospitality Group.',
      time: '10 mins ago',
      type: 'booking',
    },
    {
      id: 'notif-2',
      title: 'Counter Offer Received',
      desc: 'StageCraft Event Solutions sent a counter offer of ₹11,000 for Conference AV Production Kit.',
      time: '1 hour ago',
      type: 'offer',
    },
    {
      id: 'notif-3',
      title: 'Photo Audit Approved',
      desc: 'Audit AUD-301 condition verified. Refundable security deposit release initiated.',
      time: 'Yesterday',
      type: 'audit',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div 
        className="bg-card w-full max-w-md rounded-2xl border border-border shadow-2xl p-5 relative animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-center justify-between pb-3 border-b border-border">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-primary" />
            <h3 className="font-serif font-bold text-base text-foreground">{t.notifications}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-muted-foreground hover:text-foreground"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="divide-y divide-border py-2 max-h-[60vh] overflow-y-auto">
          {items.map((item) => (
            <div key={item.id} className="py-3 flex items-start gap-3">
              <div className="mt-0.5 p-1.5 rounded-lg bg-primary/10 text-primary shrink-0">
                {item.type === 'booking' && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                {item.type === 'offer' && <MessageSquare className="w-4 h-4 text-blue-600" />}
                {item.type === 'audit' && <ShieldCheck className="w-4 h-4 text-primary" />}
              </div>
              <div className="flex-1 text-xs">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-foreground">{item.title}</h4>
                  <span className="text-[10px] text-muted-foreground">{item.time}</span>
                </div>
                <p className="text-muted-foreground mt-0.5 leading-relaxed">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="pt-3 border-t border-border flex items-center justify-between">
          <button
            onClick={() => {
              onClose();
              onViewDashboard();
            }}
            className="text-xs font-semibold text-primary hover:underline flex items-center gap-1"
          >
            <span>Open Dashboard</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onClose}
            className="px-3 py-1.5 text-xs font-semibold rounded bg-muted text-foreground hover:bg-muted/80"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
