import React from 'react';
import { 
  Building2, 
  MapPin, 
  Star, 
  ShieldCheck, 
  Phone, 
  Mail, 
  Package, 
  CheckCircle,
  ExternalLink 
} from 'lucide-react';
import { ProviderProfile, Language } from '../types';
import { translations } from '../data/translations';

interface ProvidersViewProps {
  providers: ProviderProfile[];
  lang: Language;
  onFilterByProvider: (providerName: string) => void;
}

export const ProvidersView: React.FC<ProvidersViewProps> = ({
  providers,
  lang,
  onFilterByProvider,
}) => {
  const t = translations[lang];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
      
      {/* Title */}
      <div className="max-w-3xl mb-10">
        <span className="text-xs font-bold uppercase tracking-wider text-primary">
          Hospitality Directory
        </span>
        <h1 className="font-serif text-3xl sm:text-4xl font-bold text-foreground mt-1">
          {t.providers}
        </h1>
        <p className="text-sm sm:text-base text-muted-foreground mt-2 leading-relaxed">
          Connect directly with verified hotel groups, convention centers, catering logistics fleets, and event production enterprises across MMR.
        </p>
      </div>

      {/* Grid of Providers */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {providers.map((p) => (
          <article 
            key={p.id}
            className="rounded-2xl border border-border bg-card p-6 shadow-xs hover:editorial-shadow transition-all space-y-4 flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center font-serif text-xl font-bold border border-primary/20 shrink-0">
                    {p.name.charAt(0)}
                  </div>
                  <div>
                    <h2 className="font-serif font-bold text-lg text-foreground line-clamp-1">
                      {p.name}
                    </h2>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                      <span className="inline-flex items-center gap-1 font-medium">
                        <MapPin className="w-3.5 h-3.5" />
                        {p.city}
                      </span>
                      <span>·</span>
                      <span className="inline-flex items-center gap-1 font-bold text-foreground">
                        <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                        {p.rating} ({p.reviews})
                      </span>
                    </div>
                  </div>
                </div>

                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950 px-2 py-1 rounded-sm shrink-0">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  {t.verified}
                </span>
              </div>

              <p className="text-xs text-muted-foreground leading-relaxed">
                {p.description}
              </p>

              {/* Badges / Categories */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {p.categories.map((c) => (
                  <span key={c} className="text-[10px] font-semibold bg-muted text-muted-foreground px-2 py-0.5 rounded-sm capitalize">
                    {(t as any)[c] || c}
                  </span>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-border flex items-center justify-between gap-3">
              <div className="text-xs text-muted-foreground">
                <span className="font-bold text-foreground">{p.activeListings}</span> active resources · <span className="font-bold text-foreground">{p.completedRentals}</span> completed
              </div>

              <button
                onClick={() => onFilterByProvider(p.name)}
                className="py-1.5 px-3 rounded-lg bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground text-xs font-semibold transition-colors flex items-center gap-1.5"
              >
                <span>Browse Inventory</span>
                <ExternalLink className="w-3 h-3" />
              </button>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
};
