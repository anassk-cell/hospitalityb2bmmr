import React, { useState } from 'react';
import { 
  X, 
  Calendar, 
  MapPin, 
  CheckCircle2, 
  ShieldCheck, 
  Truck, 
  Store, 
  CreditCard, 
  QrCode, 
  Building2, 
  Lock, 
  Sparkles,
  ArrowRight,
  Info
} from 'lucide-react';
import { Resource, BookingRequest, Language } from '../types';
import { translations } from '../data/translations';

interface RequestRentalModalProps {
  resource: Resource | null;
  lang: Language;
  onClose: () => void;
  onConfirmBooking: (booking: BookingRequest) => void;
}

export const RequestRentalModal: React.FC<RequestRentalModalProps> = ({
  resource,
  lang,
  onClose,
  onConfirmBooking,
}) => {
  if (!resource) return null;

  const t = translations[lang];

  // Form states
  const todayStr = new Date().toISOString().split('T')[0];
  const nextWeekStr = new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

  const [dateFrom, setDateFrom] = useState(todayStr);
  const [dateUntil, setDateUntil] = useState(nextWeekStr);
  const [quantity, setQuantity] = useState(1);
  const [logistics, setLogistics] = useState<'delivery' | 'pickup'>('delivery');
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'netBanking'>('upi');
  const [isSuccess, setIsSuccess] = useState(false);
  const [confirmedBookingId, setConfirmedBookingId] = useState('');

  // Calculate days / events duration
  const start = new Date(dateFrom);
  const end = new Date(dateUntil);
  const diffTime = Math.max(1, Math.round((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1);
  const duration = resource.unit === 'day' ? diffTime : 1;

  // Financial computations
  const basePrice = resource.price * duration * quantity;
  const distanceKm = 6.4;
  const logisticsFee = logistics === 'delivery' ? 1200 : 0;
  const deposit = (resource.deposit || 5000) * quantity;
  const total = basePrice + logisticsFee + deposit;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const bookingId = `BK-${Math.floor(1000 + Math.random() * 9000)}`;
    const newBooking: BookingRequest = {
      id: bookingId,
      resourceId: resource.id,
      resourceName: resource.name,
      provider: resource.provider,
      city: resource.city,
      dateFrom,
      dateUntil,
      quantity,
      logistics,
      distanceKm,
      basePrice,
      logisticsFee,
      deposit,
      total,
      paymentMethod,
      status: 'accepted',
      createdAt: new Date().toISOString().split('T')[0],
    };

    setConfirmedBookingId(bookingId);
    setIsSuccess(true);
    onConfirmBooking(newBooking);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div 
        className="bg-card w-full max-w-xl rounded-2xl border border-border shadow-2xl overflow-hidden relative animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-border bg-muted/30">
          <div>
            <h2 className="font-serif text-xl font-bold text-foreground">
              {isSuccess ? t.bookingConfirmed : t.checkout}
            </h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              {resource.name} · {resource.provider}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSuccess ? (
          /* Confirmation Success Screen */
          <div className="p-6 sm:p-8 text-center space-y-6">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400 mx-auto flex items-center justify-center shadow-lg">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 bg-emerald-50 dark:bg-emerald-950/80 px-2.5 py-1 rounded-full">
                {t.calendarLocked}
              </span>
              <h3 className="font-serif text-2xl font-bold text-foreground mt-2">
                {t.paymentSuccess}
              </h3>
              <p className="text-xs text-muted-foreground mt-1 font-mono">
                Ref: {confirmedBookingId}
              </p>
            </div>

            {/* Receipt Summary Card */}
            <div className="p-4 rounded-xl bg-muted/50 border border-border text-left text-xs space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">{t.dates}:</span>
                <span className="font-semibold text-foreground">{dateFrom} → {dateUntil} ({duration} {resource.unit === 'day' ? t.day : t.eventUnit})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">{t.quantity}:</span>
                <span className="font-semibold text-foreground">{quantity} unit(s)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">{t.delivery}:</span>
                <span className="font-semibold text-foreground">{logistics === 'delivery' ? t.delivery : t.pickup}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-border">
                <span className="font-bold text-foreground">{t.total}:</span>
                <span className="font-serif font-bold text-base text-primary">₹{total.toLocaleString('en-IN')}</span>
              </div>
            </div>

            <p className="text-[11px] text-muted-foreground italic">
              {t.demoNotice}
            </p>

            <button
              onClick={onClose}
              className="w-full py-2.5 bg-primary text-primary-foreground text-xs font-semibold rounded-lg hover:bg-primary/90 transition-colors shadow-sm"
            >
              {t.done}
            </button>
          </div>
        ) : (
          /* Booking Form */
          <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-5 max-h-[80vh] overflow-y-auto">
            {/* Resource Snapshot */}
            <div className="flex items-center gap-3 p-3 bg-muted/40 rounded-xl border border-border">
              <img
                src={resource.image}
                alt={resource.name}
                className="w-16 h-12 object-cover rounded-lg shrink-0"
              />
              <div className="flex-1 min-w-0">
                <h4 className="text-xs font-bold text-foreground truncate">{resource.name}</h4>
                <p className="text-[11px] text-muted-foreground truncate">{resource.provider} · {resource.city}</p>
                <p className="text-xs font-semibold text-primary mt-0.5">
                  ₹{resource.price.toLocaleString('en-IN')} / {resource.unit === 'day' ? t.day : t.eventUnit}
                </p>
              </div>
            </div>

            {/* Dates row */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="block text-xs font-bold text-foreground">{t.from}</label>
                <div className="relative">
                  <Calendar className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                  <input
                    type="date"
                    required
                    value={dateFrom}
                    onChange={(e) => setDateFrom(e.target.value)}
                    className="w-full pl-8 pr-2 py-2 text-xs bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-bold text-foreground">{t.until}</label>
                <div className="relative">
                  <Calendar className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                  <input
                    type="date"
                    required
                    value={dateUntil}
                    onChange={(e) => setDateUntil(e.target.value)}
                    className="w-full pl-8 pr-2 py-2 text-xs bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
              </div>
            </div>

            {/* Quantity Selector */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-foreground">{t.quantityLabel}</label>
              <div className="flex items-center gap-3">
                {[1, 2, 3].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => setQuantity(num)}
                    className={`flex-1 py-1.5 text-xs font-semibold rounded-lg border transition-colors ${
                      quantity === num
                        ? 'bg-primary text-primary-foreground border-primary'
                        : 'bg-card border-border hover:bg-muted text-foreground'
                    }`}
                  >
                    {num} unit{num > 1 ? 's' : ''}
                  </button>
                ))}
              </div>
            </div>

            {/* Logistics Option */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-foreground">{t.logistics}</label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setLogistics('delivery')}
                  className={`p-3 rounded-xl border text-left transition-colors flex items-start gap-2.5 ${
                    logistics === 'delivery'
                      ? 'border-primary bg-primary/5 text-foreground'
                      : 'border-border bg-card text-muted-foreground hover:bg-muted'
                  }`}
                >
                  <Truck className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                  <div>
                    <div className="text-xs font-bold text-foreground">{t.delivery}</div>
                    <div className="text-[11px] text-muted-foreground">Approx. {distanceKm} km · ₹1,200</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setLogistics('pickup')}
                  className={`p-3 rounded-xl border text-left transition-colors flex items-start gap-2.5 ${
                    logistics === 'pickup'
                      ? 'border-primary bg-primary/5 text-foreground'
                      : 'border-border bg-card text-muted-foreground hover:bg-muted'
                  }`}
                >
                  <Store className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                  <div>
                    <div className="text-xs font-bold text-foreground">{t.pickup}</div>
                    <div className="text-[11px] text-muted-foreground">Provider location · ₹0</div>
                  </div>
                </button>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-foreground">{t.paymentMethod}</label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('upi')}
                  className={`py-2 px-2 rounded-lg border text-center text-xs font-semibold transition-colors flex flex-col items-center gap-1 ${
                    paymentMethod === 'upi'
                      ? 'border-primary bg-primary/10 text-primary font-bold'
                      : 'border-border bg-card text-foreground hover:bg-muted'
                  }`}
                >
                  <QrCode className="w-4 h-4" />
                  <span>{t.upi}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`py-2 px-2 rounded-lg border text-center text-xs font-semibold transition-colors flex flex-col items-center gap-1 ${
                    paymentMethod === 'card'
                      ? 'border-primary bg-primary/10 text-primary font-bold'
                      : 'border-border bg-card text-foreground hover:bg-muted'
                  }`}
                >
                  <CreditCard className="w-4 h-4" />
                  <span>{t.card}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('netBanking')}
                  className={`py-2 px-2 rounded-lg border text-center text-xs font-semibold transition-colors flex flex-col items-center gap-1 ${
                    paymentMethod === 'netBanking'
                      ? 'border-primary bg-primary/10 text-primary font-bold'
                      : 'border-border bg-card text-foreground hover:bg-muted'
                  }`}
                >
                  <Building2 className="w-4 h-4" />
                  <span>{t.netBanking}</span>
                </button>
              </div>
            </div>

            {/* Price Breakdown Card */}
            <div className="p-4 rounded-xl bg-muted/60 border border-border text-xs space-y-2">
              <div className="flex justify-between text-muted-foreground">
                <span>{t.basePrice} ({duration} {resource.unit === 'day' ? t.day : t.eventUnit} × {quantity}):</span>
                <span>₹{basePrice.toLocaleString('en-IN')}</span>
              </div>
              {logisticsFee > 0 && (
                <div className="flex justify-between text-muted-foreground">
                  <span>{t.logisticsFee}:</span>
                  <span>₹{logisticsFee.toLocaleString('en-IN')}</span>
                </div>
              )}
              <div className="flex justify-between text-muted-foreground">
                <span className="flex items-center gap-1">
                  <span>{t.securityDeposit}</span>
                  <Info className="w-3 h-3" />
                </span>
                <span>₹{deposit.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-border font-bold text-sm text-foreground">
                <span>{t.total}:</span>
                <span className="font-serif text-lg text-primary">₹{total.toLocaleString('en-IN')}</span>
              </div>
            </div>

            {/* Escrow & Photo Audit Guarantee */}
            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 text-xs">
              <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>{t.secureBooking} · {t.photoAudit} required upon check-in</span>
            </div>

            {/* Submit */}
            <button
              type="submit"
              className="w-full py-3 bg-primary text-primary-foreground text-xs sm:text-sm font-semibold rounded-lg hover:bg-[#133c32] shadow-md transition-all active:scale-98 flex items-center justify-center gap-2"
            >
              <Lock className="w-4 h-4" />
              <span>{t.confirmPayment}</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
