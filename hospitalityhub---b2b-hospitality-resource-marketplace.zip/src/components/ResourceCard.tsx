import React from 'react';
import { 
  Heart, 
  MapPin, 
  Star, 
  ShieldCheck, 
  Check, 
  Layers, 
  Scale, 
  ArrowUpRight,
  Sparkles
} from 'lucide-react';
import { Resource, Language } from '../types';
import { translations } from '../data/translations';

interface ResourceCardProps {
  resource: Resource;
  lang: Language;
  isSaved: boolean;
  onToggleSave: (id: number) => void;
  isCompared: boolean;
  onToggleCompare: (id: number) => void;
  onViewDetails: (resource: Resource) => void;
  onRequestRental: (resource: Resource) => void;
  onNegotiate: (resource: Resource) => void;
}

export const ResourceCard: React.FC<ResourceCardProps> = ({
  resource,
  lang,
  isSaved,
  onToggleSave,
  isCompared,
  onToggleCompare,
  onViewDetails,
  onRequestRental,
  onNegotiate,
}) => {
  const t = translations[lang];

  // Helper for status badge styling
  const getStatusBadge = () => {
    switch (resource.status) {
      case 'available':
        return (
          <span className="inline-flex items-center gap-1.5 rounded-sm px-2.5 py-1 text-[11px] font-bold bg-[#e3f5ec] text-[#135d3d] dark:bg-emerald-950/80 dark:text-emerald-300 shadow-xs">
            <span aria-hidden="true" className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
            {t.available}
          </span>
        );
      case 'negotiating':
        return (
          <span className="inline-flex items-center gap-1.5 rounded-sm px-2.5 py-1 text-[11px] font-bold bg-[#fef3c7] text-[#92400e] dark:bg-amber-950/80 dark:text-amber-300 shadow-xs">
            <span>◐</span>
            {t.negotiating}
          </span>
        );
      case 'prebooked':
        return (
          <span className="inline-flex items-center gap-1.5 rounded-sm px-2.5 py-1 text-[11px] font-bold bg-[#f3e8ff] text-[#6b21a8] dark:bg-purple-950/80 dark:text-purple-300 shadow-xs">
            <span>◈</span>
            {t.prebooked}
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 rounded-sm px-2.5 py-1 text-[11px] font-bold bg-muted text-muted-foreground shadow-xs">
            {t.unavailable}
          </span>
        );
    }
  };

  return (
    <article className="group rounded-xl overflow-hidden border border-border bg-card transition-all duration-300 hover:-translate-y-1 hover:editorial-shadow flex flex-col justify-between">
      <div>
        {/* Card Media Header with Aspect Ratio 1.48 */}
        <div className="relative aspect-[1.48] overflow-hidden bg-muted">
          <img
            src={resource.image}
            alt={resource.name}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />

          {/* Status badge top left */}
          <div className="absolute left-3 top-3 flex gap-2">
            {getStatusBadge()}
          </div>

          {/* Heart favorite button top right */}
          <button
            onClick={() => onToggleSave(resource.id)}
            className="inline-flex items-center justify-center whitespace-nowrap text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring bg-card/90 text-foreground shadow-sm hover:bg-card absolute right-3 top-3 size-9 rounded-full backdrop-blur-xs"
            aria-label={isSaved ? t.removeSaved : t.save}
            title={isSaved ? t.removeSaved : t.save}
          >
            <Heart className={`w-4 h-4 transition-colors ${isSaved ? 'text-rose-600 fill-rose-600' : 'text-muted-foreground hover:text-foreground'}`} />
          </button>

          {/* Booking type tag bottom left */}
          <div className="absolute bottom-3 left-3 rounded-sm bg-card/95 backdrop-blur-xs px-2.5 py-1 text-[11px] font-bold text-foreground border border-border/50 shadow-xs">
            {resource.booking === 'planned' ? `▦ ${t.planned}` : `⚡ ${t.emergency}`}
          </div>

          {/* Match score top-right next to heart */}
          <div className="absolute bottom-3 right-3 rounded-sm bg-primary/95 text-primary-foreground backdrop-blur-xs px-2 py-0.5 text-[10px] font-bold shadow-xs">
            {resource.match}% {t.match}
          </div>
        </div>

        {/* Card Content Details */}
        <div className="p-4 sm:p-5">
          {/* Provider name and Verified Badge */}
          <div className="flex items-center justify-between gap-2 mb-1.5">
            <span className="text-xs text-muted-foreground truncate font-medium">
              {resource.provider}
            </span>
            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-1.5 py-0.5 rounded-sm">
              <ShieldCheck className="w-3 h-3 text-emerald-600" />
              {t.verified}
            </span>
          </div>

          {/* Resource title */}
          <button
            onClick={() => onViewDetails(resource)}
            className="text-left w-full group/title focus:outline-none"
          >
            <h3 className="font-serif text-lg font-bold text-foreground line-clamp-1 group-hover/title:text-primary transition-colors">
              {resource.name}
            </h3>
          </button>

          {/* Location & Rating row */}
          <div className="flex items-center justify-between text-xs text-muted-foreground mt-2 pb-3 border-b border-border/60">
            <div className="flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-muted-foreground/70" />
              <span>{resource.city}</span>
            </div>
            <div className="flex items-center gap-1">
              <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              <span className="font-bold text-foreground">{resource.rating}</span>
              <span>({resource.reviews})</span>
            </div>
            <div>
              <span className="font-medium text-foreground">{resource.quantity}</span> {t.units}
            </div>
          </div>

          {/* Key Specs Pills */}
          <div className="mt-3 flex flex-wrap gap-1.5">
            {resource.specs.slice(0, 2).map((spec, i) => (
              <span key={i} className="text-[11px] bg-muted text-muted-foreground px-2 py-0.5 rounded-sm truncate max-w-full">
                {spec}
              </span>
            ))}
          </div>

          {/* Price display */}
          <div className="mt-4 flex items-baseline justify-between">
            <div className="text-xs text-muted-foreground font-medium">
              {t.priceFrom}
            </div>
            <div className="text-right">
              <span className="text-lg sm:text-xl font-bold font-serif text-foreground">
                ₹{resource.price.toLocaleString('en-IN')}
              </span>
              <span className="text-xs text-muted-foreground ml-1">
                / {resource.unit === 'day' ? t.day : t.eventUnit}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons Row */}
      <div className="p-4 sm:p-5 pt-0 space-y-2">
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => onViewDetails(resource)}
            className="w-full py-2 px-2.5 text-xs font-semibold rounded-md border border-border bg-card text-foreground hover:bg-muted transition-colors text-center truncate"
          >
            {t.details}
          </button>

          <button
            onClick={() => onRequestRental(resource)}
            className="w-full py-2 px-2.5 text-xs font-semibold rounded-md bg-primary text-primary-foreground hover:bg-[#133c32] transition-colors shadow-xs text-center truncate"
          >
            {t.request}
          </button>
        </div>

        <div className="flex items-center justify-between pt-1 gap-2">
          <button
            onClick={() => onNegotiate(resource)}
            className="text-xs font-semibold text-primary hover:underline transition-colors flex items-center gap-1 py-1"
          >
            <span>{t.negotiate}</span>
            <ArrowUpRight className="w-3 h-3" />
          </button>

          <button
            onClick={() => onToggleCompare(resource.id)}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-sm text-xs font-medium border transition-colors ${
              isCompared
                ? 'bg-primary/10 border-primary text-primary font-bold'
                : 'border-border/80 text-muted-foreground hover:text-foreground hover:bg-muted'
            }`}
          >
            <Scale className="w-3 h-3" />
            <span>{isCompared ? `✓ ${t.compared}` : t.compared}</span>
          </button>
        </div>
      </div>
    </article>
  );
};
