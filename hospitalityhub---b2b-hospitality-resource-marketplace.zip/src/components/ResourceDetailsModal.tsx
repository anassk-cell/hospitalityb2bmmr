import React, { useState } from 'react';
import { 
  X, 
  MapPin, 
  Star, 
  ShieldCheck, 
  Calendar, 
  CheckCircle2, 
  Lock, 
  ChevronLeft, 
  ChevronRight, 
  Sparkles,
  Building,
  Clock,
  Phone,
  Mail,
  ArrowRight
} from 'lucide-react';
import { Resource, Language } from '../types';
import { translations } from '../data/translations';

interface ResourceDetailsModalProps {
  resource: Resource | null;
  lang: Language;
  onClose: () => void;
  onRequestRental: (resource: Resource) => void;
  onNegotiate: (resource: Resource) => void;
}

export const ResourceDetailsModal: React.FC<ResourceDetailsModalProps> = ({
  resource,
  lang,
  onClose,
  onRequestRental,
  onNegotiate,
}) => {
  if (!resource) return null;

  const t = translations[lang];
  const photos = resource.photos || [resource.image];
  const [activePhotoIdx, setActivePhotoIdx] = useState(0);

  // Generate next 14 days dates for availability grid
  const today = new Date();
  const next14Days = Array.from({ length: 14 }, (_, i) => {
    const d = new Date(today);
    d.setDate(today.getDate() + i);
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    const isoString = `${yyyy}-${mm}-${dd}`;
    const dayName = d.toLocaleDateString(lang === 'hi' ? 'hi-IN' : 'en-US', { weekday: 'short' });
    const dayNum = d.getDate();
    return { isoString, dayName, dayNum };
  });

  const lockedDates = resource.lockedDates || [];
  const [selectedCalendarDate, setSelectedCalendarDate] = useState<string | null>(null);

  const prevPhoto = () => {
    setActivePhotoIdx((prev) => (prev > 0 ? prev - 1 : photos.length - 1));
  };

  const nextPhoto = () => {
    setActivePhotoIdx((prev) => (prev < photos.length - 1 ? prev + 1 : 0));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div 
        className="bg-card w-full max-w-4xl rounded-2xl border border-border shadow-2xl overflow-hidden my-auto relative animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
        aria-labelledby="details-title"
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-card/80 backdrop-blur-xs text-foreground hover:bg-card border border-border shadow-md transition-colors"
          aria-label={t.close}
        >
          <X className="w-5 h-5" />
        </button>

        <div className="max-h-[90vh] overflow-y-auto">
          {/* Photo Gallery with Carousel */}
          <div className="relative aspect-[16/9] sm:aspect-[21/9] bg-muted overflow-hidden group">
            <img
              src={photos[activePhotoIdx]}
              alt={`${resource.name} - ${activePhotoIdx + 1}`}
              className="w-full h-full object-cover transition-all duration-300"
            />

            {photos.length > 1 && (
              <>
                <button
                  onClick={prevPhoto}
                  className="absolute left-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/50 text-white hover:bg-black/70 transition-colors"
                  aria-label={t.galleryPrevious}
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  onClick={nextPhoto}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/50 text-white hover:bg-black/70 transition-colors"
                  aria-label={t.galleryNext}
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
                
                {/* Dots indicator */}
                <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 bg-black/40 backdrop-blur-xs px-2.5 py-1 rounded-full">
                  {photos.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setActivePhotoIdx(i)}
                      className={`w-2 h-2 rounded-full transition-all ${
                        activePhotoIdx === i ? 'bg-white w-4' : 'bg-white/50'
                      }`}
                      aria-label={`Photo ${i + 1}`}
                    />
                  ))}
                </div>
              </>
            )}

            {/* Badges on Gallery */}
            <div className="absolute top-4 left-4 flex flex-wrap gap-2">
              <span className="px-2.5 py-1 rounded-sm text-xs font-bold bg-[#e3f5ec] text-[#135d3d] shadow-sm">
                ● {t.available}
              </span>
              <span className="px-2.5 py-1 rounded-sm text-xs font-bold bg-primary text-primary-foreground shadow-sm">
                {resource.match}% {t.match}
              </span>
            </div>
          </div>

          {/* Modal Content */}
          <div className="p-5 sm:p-8 space-y-6">
            
            {/* Header info */}
            <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 border-b border-border pb-6">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-primary">
                    {(t as any)[resource.category] || resource.category}
                  </span>
                  <span className="text-muted-foreground">·</span>
                  <span className="inline-flex items-center gap-1 text-xs text-muted-foreground font-medium">
                    <MapPin className="w-3.5 h-3.5" />
                    {resource.city}
                  </span>
                </div>

                <h2 id="details-title" className="font-serif text-2xl sm:text-3xl font-bold text-foreground">
                  {resource.name}
                </h2>

                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1 font-bold text-foreground">
                    <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                    {resource.rating}
                  </span>
                  <span>({resource.reviews} {t.reviews})</span>
                  <span>·</span>
                  <span className="font-medium text-foreground">{resource.rentals} {t.completedRentals}</span>
                </div>
              </div>

              {/* Price Callout */}
              <div className="p-4 rounded-xl bg-secondary/50 border border-border shrink-0 text-left md:text-right">
                <div className="text-xs text-muted-foreground font-medium">{t.priceFrom}</div>
                <div className="font-serif text-2xl sm:text-3xl font-bold text-foreground">
                  ₹{resource.price.toLocaleString('en-IN')}
                </div>
                <div className="text-xs text-muted-foreground">
                  / {resource.unit === 'day' ? t.day : t.eventUnit}
                </div>
                {resource.deposit && (
                  <div className="text-[11px] text-muted-foreground mt-1">
                    {t.securityDeposit}: ₹{resource.deposit.toLocaleString('en-IN')}
                  </div>
                )}
              </div>
            </div>

            {/* Description & Specifications Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Description */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">
                  {t.description}
                </h3>
                <p className="text-sm text-foreground/90 leading-relaxed">
                  {resource.description}
                </p>

                {/* Provider Card */}
                <div className="mt-5 p-4 rounded-xl bg-muted/50 border border-border space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-foreground flex items-center gap-1.5">
                      <Building className="w-4 h-4 text-primary" />
                      {resource.provider}
                    </span>
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded-sm">
                      <ShieldCheck className="w-3 h-3 text-emerald-600" />
                      {t.verified}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Hospitality partner in {resource.city} with verified operational credentials and audited inventory.
                  </p>
                </div>
              </div>

              {/* Specifications */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">
                  {t.specifications}
                </h3>
                <ul className="space-y-2">
                  {resource.specs.map((spec, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-foreground bg-card p-2 rounded-lg border border-border/70">
                      <CheckCircle2 className="w-4 h-4 text-primary shrink-0" />
                      <span>{spec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* 14-Day Availability Calendar Grid */}
            <div className="space-y-3 border-t border-border pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-foreground flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-primary" />
                    {t.availability} ({t.nextDays})
                  </h3>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {t.calendarHint}
                  </p>
                </div>
                <div className="flex items-center gap-3 text-xs">
                  <span className="flex items-center gap-1 text-emerald-700 dark:text-emerald-400">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                    {t.available}
                  </span>
                  <span className="flex items-center gap-1 text-muted-foreground">
                    <Lock className="w-3 h-3 text-muted-foreground" />
                    {t.locked}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
                {next14Days.map((item) => {
                  const isLocked = lockedDates.includes(item.isoString);
                  const isSelected = selectedCalendarDate === item.isoString;

                  return (
                    <button
                      key={item.isoString}
                      disabled={isLocked}
                      onClick={() => setSelectedCalendarDate(item.isoString)}
                      className={`flex flex-col items-center justify-center p-2 rounded-lg border text-xs transition-all ${
                        isLocked
                          ? 'bg-muted/70 border-border text-muted-foreground/60 cursor-not-allowed'
                          : isSelected
                          ? 'bg-primary text-primary-foreground border-primary font-bold shadow-xs scale-102'
                          : 'bg-card border-border hover:border-primary/50 text-foreground'
                      }`}
                    >
                      <span className="text-[10px] uppercase font-semibold">{item.dayName}</span>
                      <span className="text-sm font-bold mt-0.5">{item.dayNum}</span>
                      <span className="text-[9px] mt-0.5">
                        {isLocked ? <Lock className="w-2.5 h-2.5 inline" /> : '●'}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="border-t border-border pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-xs text-muted-foreground">
                <span className="font-semibold text-foreground">{resource.quantity}</span> {t.units} · Direct business contract
              </div>

              <div className="flex items-center gap-3 w-full sm:w-auto">
                <button
                  onClick={() => {
                    onClose();
                    onNegotiate(resource);
                  }}
                  className="flex-1 sm:flex-none py-2.5 px-4 text-xs font-semibold rounded-lg border border-border bg-card text-foreground hover:bg-muted transition-colors text-center"
                >
                  {t.offerTitle}
                </button>

                <button
                  onClick={() => {
                    onClose();
                    onRequestRental(resource);
                  }}
                  className="flex-1 sm:flex-none py-2.5 px-6 text-xs font-semibold rounded-lg bg-primary text-primary-foreground hover:bg-[#133c32] shadow-md transition-colors flex items-center justify-center gap-2"
                >
                  <span>{t.request}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};
