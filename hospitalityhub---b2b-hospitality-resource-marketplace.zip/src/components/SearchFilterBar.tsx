import React from 'react';
import { 
  Search, 
  MapPin, 
  Calendar, 
  Layers, 
  Zap, 
  CalendarDays, 
  X, 
  SlidersHorizontal 
} from 'lucide-react';
import { CategoryKey, BookingType, Language } from '../types';
import { CATEGORIES } from '../data/mockData';
import { translations } from '../data/translations';

interface SearchFilterBarProps {
  lang: Language;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  locationFilter: string;
  onLocationChange: (loc: string) => void;
  dateFrom: string;
  onDateFromChange: (d: string) => void;
  dateUntil: string;
  onDateUntilChange: (d: string) => void;
  quantityFilter: number;
  onQuantityChange: (q: number) => void;
  bookingTypeFilter: 'all' | BookingType;
  onBookingTypeChange: (bt: 'all' | BookingType) => void;
  activeCategory: CategoryKey;
  onSelectCategory: (cat: CategoryKey) => void;
  onResetFilters: () => void;
  hasActiveFilters: boolean;
}

export const SearchFilterBar: React.FC<SearchFilterBarProps> = ({
  lang,
  searchQuery,
  onSearchChange,
  locationFilter,
  onLocationChange,
  dateFrom,
  onDateFromChange,
  dateUntil,
  onDateUntilChange,
  quantityFilter,
  onQuantityChange,
  bookingTypeFilter,
  onBookingTypeChange,
  activeCategory,
  onSelectCategory,
  onResetFilters,
  hasActiveFilters,
}) => {
  const t = translations[lang];

  return (
    <div className="w-full">
      {/* Search card floating/nested */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 sm:-mt-10 relative z-20">
        <div className="bg-card rounded-xl border border-border shadow-xl p-4 sm:p-6 editorial-shadow transition-colors">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-primary" />
              {t.searchTitle}
            </h2>
            {hasActiveFilters && (
              <button
                onClick={onResetFilters}
                className="text-xs font-semibold text-primary hover:text-primary/80 flex items-center gap-1"
              >
                <X className="w-3.5 h-3.5" />
                {t.reset}
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 sm:gap-4 items-end">
            
            {/* What do you need */}
            <div className="lg:col-span-2 space-y-1.5">
              <label htmlFor="search-input" className="block text-xs font-bold text-foreground">
                {t.what}
              </label>
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  id="search-input"
                  type="text"
                  value={searchQuery}
                  onChange={(e) => onSearchChange(e.target.value)}
                  placeholder={t.whatPlaceholder}
                  className="w-full pl-9 pr-3 py-2.5 text-xs sm:text-sm bg-background border border-border rounded-lg text-foreground placeholder:text-muted-foreground/70 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
                />
                {searchQuery && (
                  <button
                    onClick={() => onSearchChange('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    aria-label="Clear search input"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {/* Location */}
            <div className="space-y-1.5">
              <label htmlFor="location-select" className="block text-xs font-bold text-foreground">
                {t.location}
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <select
                  id="location-select"
                  value={locationFilter}
                  onChange={(e) => onLocationChange(e.target.value)}
                  className="w-full pl-9 pr-8 py-2.5 text-xs sm:text-sm bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent appearance-none transition-all"
                >
                  <option value="">{lang === 'en' ? 'All Locations (MMR)' : 'सभी स्थान'}</option>
                  <option value="Mumbai">Mumbai</option>
                  <option value="Navi Mumbai">Navi Mumbai</option>
                  <option value="Thane">Thane</option>
                  <option value="Panvel">Panvel</option>
                  <option value="Pune">Pune</option>
                </select>
              </div>
            </div>

            {/* Required From */}
            <div className="space-y-1.5">
              <label htmlFor="date-from-input" className="block text-xs font-bold text-foreground">
                {t.from}
              </label>
              <div className="relative">
                <Calendar className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                <input
                  id="date-from-input"
                  type="date"
                  value={dateFrom}
                  onChange={(e) => onDateFromChange(e.target.value)}
                  className="w-full pl-9 pr-2 py-2.5 text-xs sm:text-sm bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
                />
              </div>
            </div>

            {/* Required Until */}
            <div className="space-y-1.5">
              <label htmlFor="date-until-input" className="block text-xs font-bold text-foreground">
                {t.until}
              </label>
              <div className="relative">
                <Calendar className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                <input
                  id="date-until-input"
                  type="date"
                  value={dateUntil}
                  onChange={(e) => onDateUntilChange(e.target.value)}
                  className="w-full pl-9 pr-2 py-2.5 text-xs sm:text-sm bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
                />
              </div>
            </div>

            {/* Booking Type Filter */}
            <div className="space-y-1.5">
              <label htmlFor="booking-type-select" className="block text-xs font-bold text-foreground">
                {t.bookingType}
              </label>
              <div className="relative">
                <select
                  id="booking-type-select"
                  value={bookingTypeFilter}
                  onChange={(e) => onBookingTypeChange(e.target.value as 'all' | BookingType)}
                  className="w-full px-3 py-2.5 text-xs sm:text-sm bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
                >
                  <option value="all">{t.allBookingTypes}</option>
                  <option value="planned">▦ {t.planned}</option>
                  <option value="emergency">⚡ {t.emergency}</option>
                </select>
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* Category Strip */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-6">
        <div className="mb-4">
          <div className="text-xs uppercase font-bold tracking-wider text-primary mb-1">
            {t.marketplace}
          </div>
          <h2 className="font-serif text-2xl sm:text-3xl text-foreground font-normal">
            {t.categories}
          </h2>
          <p className="text-xs sm:text-sm text-muted-foreground mt-1">
            {t.categoriesSub}
          </p>
        </div>

        {/* Scrollable category pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {CATEGORIES.map((cat) => {
            const isActive = activeCategory === cat.key;
            // Get category label from translations
            const catLabel = cat.key === 'all' 
              ? t.all 
              : (t as any)[cat.key] || cat.key;

            return (
              <button
                key={cat.key}
                onClick={() => onSelectCategory(cat.key)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-semibold whitespace-nowrap transition-all duration-200 border ${
                  isActive
                    ? 'bg-primary text-primary-foreground border-primary shadow-xs scale-102'
                    : 'bg-card text-foreground border-border hover:bg-muted hover:border-border/80'
                }`}
              >
                <span>{cat.icon}</span>
                <span>{catLabel}</span>
              </button>
            );
          })}
        </div>
      </section>
    </div>
  );
};
