import React from 'react';
import { 
  ShieldCheck, 
  Sparkles, 
  Calendar, 
  CircleDollarSign, 
  CalendarCheck, 
  Lock 
} from 'lucide-react';
import { Language } from '../types';
import { translations } from '../data/translations';

interface TrustSectionProps {
  lang: Language;
}

export const TrustSection: React.FC<TrustSectionProps> = ({ lang }) => {
  const t = translations[lang];

  return (
    <section className="bg-muted/40 py-16 sm:py-20 border-y border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-primary">
            {t.verifiedBusinesses}
          </span>
          <h2 className="font-serif text-2xl sm:text-4xl font-bold text-foreground mt-2">
            {t.trustTitle}
          </h2>
          <p className="text-xs sm:text-sm text-muted-foreground mt-2">
            {t.trustSub}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="p-6 rounded-xl bg-card border border-border shadow-xs space-y-2.5">
            <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="font-serif font-bold text-base text-foreground">{t.verifiedBusinesses}</h3>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Every provider is vetted with active hospitality registration and verified equipment listings.
            </p>
          </div>

          <div className="p-6 rounded-xl bg-card border border-border shadow-xs space-y-2.5">
            <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <h3 className="font-serif font-bold text-base text-foreground">{t.smartMatching}</h3>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Find resources based on proximity in Mumbai MMR, capacity needs, and live availability.
            </p>
          </div>

          <div className="p-6 rounded-xl bg-card border border-border shadow-xs space-y-2.5">
            <div className="w-10 h-10 rounded-lg bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400 flex items-center justify-center">
              <Calendar className="w-5 h-5" />
            </div>
            <h3 className="font-serif font-bold text-base text-foreground">{t.flexibleBooking}</h3>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Plan corporate banquets in advance or book urgent backup for catering kitchens and power outages.
            </p>
          </div>

          <div className="p-6 rounded-xl bg-card border border-border shadow-xs space-y-2.5">
            <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
              <CircleDollarSign className="w-5 h-5" />
            </div>
            <h3 className="font-serif font-bold text-base text-foreground">{t.transparentPricing}</h3>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Direct peer-to-peer pricing with transparent security deposits and zero broker surcharges.
            </p>
          </div>

          <div className="p-6 rounded-xl bg-card border border-border shadow-xs space-y-2.5">
            <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400 flex items-center justify-center">
              <CalendarCheck className="w-5 h-5" />
            </div>
            <h3 className="font-serif font-bold text-base text-foreground">{t.calendarAvailability}</h3>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Locked calendar dates ensure no double bookings and immediate reservation accuracy.
            </p>
          </div>

          <div className="p-6 rounded-xl bg-card border border-border shadow-xs space-y-2.5">
            <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
              <Lock className="w-5 h-5" />
            </div>
            <h3 className="font-serif font-bold text-base text-foreground">{t.secureTransactions}</h3>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Pre-rental and post-rental photo audit checkpoints guarantee full damage-free security releases.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
