import { CategoryKey, Resource, ProviderProfile, BookingRequest, NegotiationOffer, PhotoAudit } from '../types';

export const CATEGORIES: { key: CategoryKey; icon: string }[] = [
  { key: 'all', icon: '✨' },
  { key: 'spaces', icon: '🏨' },
  { key: 'kitchen', icon: '🍽' },
  { key: 'vehicles', icon: '🚐' },
  { key: 'furniture', icon: '🪑' },
  { key: 'event', icon: '🎪' },
  { key: 'av', icon: '🔊' },
  { key: 'cold', icon: '❄' },
  { key: 'logistics', icon: '🚚' },
  { key: 'utilities', icon: '⚡' },
  { key: 'other', icon: '📦' },
];

export const INITIAL_RESOURCES: Resource[] = [
  {
    id: 1,
    name: 'Grand Ballroom & Event Space',
    provider: 'The Meridian Hospitality Group',
    city: 'Mumbai',
    category: 'spaces',
    image: '/assets/hospitality-hero-DaY1D21i.jpg',
    price: 28000,
    unit: 'day',
    quantity: 1,
    rating: '4.9',
    reviews: 42,
    match: 98,
    status: 'available',
    booking: 'planned',
    description: 'A versatile, fully serviced ballroom for corporate conferences, celebrations and large-scale hospitality events. Equipped with acoustic sound treatment, chandeliers, and high-speed Wi-Fi.',
    specs: ['Capacity: 250 guests', 'Area: 4,800 sq ft', 'AV-ready setup', 'On-site valet parking', 'Dedicated service elevator', 'Air conditioning (HVAC)'],
    rentals: 186,
    deposit: 15000,
    lockedDates: ['2026-10-02', '2026-10-03', '2026-10-10'],
    photos: [
      '/assets/hospitality-hero-DaY1D21i.jpg',
      'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1200&q=80'
    ]
  },
  {
    id: 2,
    name: 'Commercial Catering Kitchen',
    provider: 'Saffron Table Hospitality',
    city: 'Navi Mumbai',
    category: 'kitchen',
    image: '/assets/commercial-kitchen-ClxfkEU-.jpg',
    price: 8500,
    unit: 'day',
    quantity: 2,
    rating: '4.8',
    reviews: 36,
    match: 96,
    status: 'available',
    booking: 'emergency',
    description: 'A professionally equipped production kitchen ready for high-volume catering, pop-up preparations, and event batch cooking. Fully certified with FSSAI hygiene standards.',
    specs: ['Capacity: 500 meals/day', 'Commercial combi-ovens', 'Walk-in cold storage (4°C & -18°C)', 'Hygiene audited & pest controlled', 'Gas ranges & stainless steel prep stations'],
    rentals: 124,
    deposit: 5000,
    lockedDates: ['2026-09-28', '2026-09-29'],
    photos: [
      '/assets/commercial-kitchen-ClxfkEU-.jpg',
      'https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1578474846511-04ba529f0b88?auto=format&fit=crop&w=1200&q=80'
    ]
  },
  {
    id: 3,
    name: '7-Seater Executive Hospitality Van',
    provider: 'TransMMR Hospitality Fleet',
    city: 'Panvel',
    category: 'vehicles',
    image: '/assets/hospitality-van-BXeo-qBs.jpg',
    price: 4500,
    unit: 'day',
    quantity: 2,
    rating: '4.8',
    reviews: 28,
    match: 96,
    status: 'available',
    booking: 'planned',
    description: 'A comfortable executive vehicle for VIP airport transfers, delegation transport, event crews, and hospitality logistics across the Mumbai Metropolitan Region.',
    specs: ['7 luxury captain seats', 'Dual-zone air conditioning', 'Professional uniformed driver option', 'Spacious rear luggage space', 'GPS tracking & fleet dashcam'],
    rentals: 98,
    deposit: 3000,
    lockedDates: ['2026-10-01', '2026-10-04'],
    photos: [
      '/assets/hospitality-van-BXeo-qBs.jpg',
      'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=1200&q=80'
    ]
  },
  {
    id: 4,
    name: 'Conference AV Production Kit',
    provider: 'StageCraft Event Solutions',
    city: 'Thane',
    category: 'av',
    image: '/assets/event-av-DDBIdn3z.jpg',
    price: 12000,
    unit: 'event',
    quantity: 3,
    rating: '4.9',
    reviews: 51,
    match: 93,
    status: 'available',
    booking: 'emergency',
    description: 'A complete professional audiovisual package for corporate conferences, summits, product reveals, and hybrid hospitality webinars.',
    specs: ['4K laser projection & display', '4x UHF wireless lapel & handheld mics', 'Digital sound mixing console', 'Setup technician included', 'Cable runs & stage DI boxes'],
    rentals: 212,
    deposit: 6000,
    lockedDates: ['2026-09-30', '2026-10-05'],
    photos: [
      '/assets/event-av-DDBIdn3z.jpg',
      'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=1200&q=80'
    ]
  },
  {
    id: 5,
    name: 'Premium Banquet Seating Set',
    provider: 'The Meridian Hospitality Group',
    city: 'Mumbai',
    category: 'furniture',
    image: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1024&q=80',
    price: 6800,
    unit: 'event',
    quantity: 4,
    rating: '4.7',
    reviews: 19,
    match: 91,
    status: 'negotiating',
    booking: 'planned',
    description: 'Refined banquet furniture package suitable for formal gala dinners, awards ceremonies, and hotel overflow requirements.',
    specs: ['Seats 80 guests total', 'Stackable gold-frame Chiavari chairs', 'Round wooden banquet tables (6ft)', 'Full ivory table linen included', 'Rapid delivery & setup available'],
    rentals: 74,
    deposit: 4000,
    lockedDates: ['2026-10-07', '2026-10-08'],
    photos: [
      'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1024&q=80',
      'https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?auto=format&fit=crop&w=1024&q=80'
    ]
  },
  {
    id: 6,
    name: 'Event Stage & Sound Setup',
    provider: 'StageCraft Event Solutions',
    city: 'Navi Mumbai',
    category: 'event',
    image: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?auto=format&fit=crop&w=1024&q=80',
    price: 16000,
    unit: 'event',
    quantity: 1,
    rating: '4.8',
    reviews: 32,
    match: 89,
    status: 'prebooked',
    booking: 'planned',
    description: 'A turnkey modular stage and line-array audio setup engineered for luxury weddings, corporate keynotes, and indoor/outdoor musical showcases.',
    specs: ['Modular stage 24ft x 16ft', 'High-throw PA line-array system', 'Intelligent LED lighting truss rig', 'Certified sound technician on-site', 'Safety skirts & guard rails'],
    rentals: 139,
    deposit: 8000,
    lockedDates: ['2026-09-27', '2026-09-28', '2026-10-01', '2026-10-02'],
    photos: [
      'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?auto=format&fit=crop&w=1024&q=80',
      '/assets/event-av-DDBIdn3z.jpg'
    ]
  },
  {
    id: 7,
    name: 'Refrigerated Mobile Cold Van (Chiller)',
    provider: 'TransMMR Hospitality Fleet',
    city: 'Mumbai',
    category: 'cold',
    image: 'https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=1024&q=80',
    price: 5500,
    unit: 'day',
    quantity: 2,
    rating: '4.9',
    reviews: 22,
    match: 94,
    status: 'available',
    booking: 'emergency',
    description: 'Temperature-controlled insulated mobile chiller van with dual standby unit (-5°C to +8°C) for perishable ingredients and banquet catering backup.',
    specs: ['Payload: 1.5 tons', 'Digital temperature log monitor', 'Standby 3-phase electric hookup', 'HACCP compliant sanitization'],
    rentals: 88,
    deposit: 4500,
    lockedDates: ['2026-10-06'],
    photos: [
      'https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=1024&q=80'
    ]
  },
  {
    id: 8,
    name: 'Heavy Duty 65kVA Silent Generator',
    provider: 'Saffron Table Hospitality',
    city: 'Thane',
    category: 'utilities',
    image: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1024&q=80',
    price: 9000,
    unit: 'day',
    quantity: 1,
    rating: '4.8',
    reviews: 17,
    match: 92,
    status: 'available',
    booking: 'emergency',
    description: 'Acoustic enclosed soundproof diesel generator set providing uninterrupted electrical backup for hospitality venues and banquets.',
    specs: ['Output: 65 kVA / 52 kW', 'Noise level < 70 dBA at 1m', 'Automatic transfer switch (ATS)', 'Dedicated technician & fuel supply option'],
    rentals: 62,
    deposit: 5000,
    lockedDates: ['2026-10-03'],
    photos: [
      'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1024&q=80'
    ]
  }
];

export const INITIAL_PROVIDERS: ProviderProfile[] = [
  {
    id: 'meridian',
    name: 'The Meridian Hospitality Group',
    city: 'Mumbai',
    rating: '4.9',
    reviews: 61,
    verified: true,
    activeListings: 8,
    completedRentals: 260,
    categories: ['spaces', 'furniture', 'kitchen'],
    description: 'Premier Mumbai luxury hotel and convention group with dedicated banquet infrastructure, ballroom suites, and premium event equipment available for peer sharing.',
    phone: '+91 (022) 4920-8800',
    email: 'resources@meridianhospitality.in'
  },
  {
    id: 'saffron',
    name: 'Saffron Table Hospitality',
    city: 'Navi Mumbai',
    rating: '4.8',
    reviews: 53,
    verified: true,
    activeListings: 6,
    completedRentals: 186,
    categories: ['kitchen', 'utilities', 'cold'],
    description: 'Commercial catering kitchen chain and culinary logistics provider supporting high-end corporate events, institutional caterers, and emergency back-kitchen relief.',
    phone: '+91 (022) 2781-4450',
    email: 'dispatch@saffrontable.com'
  },
  {
    id: 'transmmr',
    name: 'TransMMR Hospitality Fleet',
    city: 'Panvel',
    rating: '4.8',
    reviews: 50,
    verified: true,
    activeListings: 5,
    completedRentals: 186,
    categories: ['vehicles', 'logistics', 'cold'],
    description: 'Specialized passenger logistics and cold-chain fleet operators catering to luxury hotel transfers, event delegations, and perishables across MMR.',
    phone: '+91 (022) 6120-3390',
    email: 'fleet@transmmr.in'
  },
  {
    id: 'stagecraft',
    name: 'StageCraft Event Solutions',
    city: 'Thane',
    rating: '4.9',
    reviews: 83,
    verified: true,
    activeListings: 7,
    completedRentals: 351,
    categories: ['av', 'event', 'utilities'],
    description: 'B2B technical staging, trussing, concert-grade acoustic gear, and broadcast video systems for corporate conventions and luxury hotel galas.',
    phone: '+91 (022) 3954-1200',
    email: 'operations@stagecraftevents.in'
  }
];

export const INITIAL_BOOKINGS: BookingRequest[] = [
  {
    id: 'BK-8902',
    resourceId: 1,
    resourceName: 'Grand Ballroom & Event Space',
    provider: 'The Meridian Hospitality Group',
    city: 'Mumbai',
    dateFrom: '2026-10-12',
    dateUntil: '2026-10-13',
    quantity: 1,
    logistics: 'pickup',
    distanceKm: 4.2,
    basePrice: 56000,
    logisticsFee: 0,
    deposit: 15000,
    total: 71000,
    paymentMethod: 'upi',
    status: 'accepted',
    createdAt: '2026-09-25'
  },
  {
    id: 'BK-8903',
    resourceId: 2,
    resourceName: 'Commercial Catering Kitchen',
    provider: 'Saffron Table Hospitality',
    city: 'Navi Mumbai',
    dateFrom: '2026-10-04',
    dateUntil: '2026-10-05',
    quantity: 1,
    logistics: 'delivery',
    distanceKm: 8.5,
    basePrice: 17000,
    logisticsFee: 1200,
    deposit: 5000,
    total: 23200,
    paymentMethod: 'card',
    status: 'pending',
    createdAt: '2026-09-26'
  }
];

export const INITIAL_NEGOTIATIONS: NegotiationOffer[] = [
  {
    id: 'NEG-101',
    resourceId: 5,
    resourceName: 'Premium Banquet Seating Set',
    provider: 'The Meridian Hospitality Group',
    seekerName: 'Taj Conclave Events',
    originalPrice: 6800,
    proposedPrice: 5800,
    unit: 'event',
    dateFrom: '2026-10-14',
    dateUntil: '2026-10-15',
    message: 'We are booking for a 2-day conference. Can you provide 15% discount for consecutive days?',
    type: 'incoming',
    status: 'pending',
    createdAt: '2026-09-26'
  },
  {
    id: 'NEG-102',
    resourceId: 4,
    resourceName: 'Conference AV Production Kit',
    provider: 'StageCraft Event Solutions',
    seekerName: 'Metropolitan Banquet',
    originalPrice: 12000,
    proposedPrice: 10500,
    unit: 'event',
    dateFrom: '2026-10-09',
    dateUntil: '2026-10-09',
    message: 'Seeking same-day morning setup. Can technician arrive at 7:00 AM?',
    type: 'outgoing',
    status: 'countered',
    counterPrice: 11000,
    createdAt: '2026-09-24'
  }
];

export const INITIAL_AUDITS: PhotoAudit[] = [
  {
    id: 'AUD-301',
    resourceName: 'Commercial Catering Kitchen (Unit #1)',
    provider: 'Saffron Table Hospitality',
    renter: 'Oberoi Festive Kitchens',
    date: '2026-09-23',
    beforePhotos: [
      '/assets/commercial-kitchen-ClxfkEU-.jpg',
      'https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&w=600&q=80'
    ],
    afterPhotos: [
      '/assets/commercial-kitchen-ClxfkEU-.jpg',
      'https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&w=600&q=80'
    ],
    status: 'approved',
    notes: 'Hygiene audit passed. All stainless-steel countertops cleaned. Ovens deep-cleaned. Security deposit release sanctioned.'
  },
  {
    id: 'AUD-302',
    resourceName: '7-Seater Executive Hospitality Van (MH-04-8821)',
    provider: 'TransMMR Hospitality Fleet',
    renter: 'Westin Executive Transfers',
    date: '2026-09-25',
    beforePhotos: [
      '/assets/hospitality-van-BXeo-qBs.jpg'
    ],
    afterPhotos: [
      '/assets/hospitality-van-BXeo-qBs.jpg'
    ],
    status: 'pending',
    notes: 'Vehicle returned on time with fuel level checked. Odometer reading verified (+142 km).'
  }
];
