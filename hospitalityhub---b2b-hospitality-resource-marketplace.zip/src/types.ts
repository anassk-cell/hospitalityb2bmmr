export type BookingType = 'planned' | 'emergency';
export type ResourceStatus = 'available' | 'negotiating' | 'prebooked' | 'unavailable';
export type CategoryKey = 
  | 'all'
  | 'spaces'
  | 'kitchen'
  | 'vehicles'
  | 'furniture'
  | 'event'
  | 'av'
  | 'cold'
  | 'logistics'
  | 'utilities'
  | 'other';

export interface Resource {
  id: number;
  name: string;
  provider: string;
  city: string;
  category: CategoryKey;
  image: string;
  price: number;
  unit: 'day' | 'event';
  quantity: number;
  rating: string;
  reviews: number;
  match: number;
  status: ResourceStatus;
  booking: BookingType;
  description: string;
  specs: string[];
  rentals: number;
  photos?: string[];
  deposit?: number;
  lockedDates?: string[]; // YYYY-MM-DD format
}

export interface BookingRequest {
  id: string;
  resourceId: number;
  resourceName: string;
  provider: string;
  city: string;
  dateFrom: string;
  dateUntil: string;
  quantity: number;
  logistics: 'delivery' | 'pickup';
  distanceKm: number;
  basePrice: number;
  logisticsFee: number;
  deposit: number;
  total: number;
  paymentMethod: 'upi' | 'card' | 'netBanking';
  status: 'pending' | 'accepted' | 'completed' | 'rejected';
  createdAt: string;
}

export interface NegotiationOffer {
  id: string;
  resourceId: number;
  resourceName: string;
  provider: string;
  seekerName: string;
  originalPrice: number;
  proposedPrice: number;
  unit: 'day' | 'event';
  dateFrom: string;
  dateUntil: string;
  message: string;
  type: 'incoming' | 'outgoing' | 'counter';
  status: 'pending' | 'accepted' | 'rejected' | 'countered';
  counterPrice?: number;
  createdAt: string;
}

export interface PhotoAudit {
  id: string;
  resourceName: string;
  provider: string;
  renter: string;
  date: string;
  beforePhotos: string[];
  afterPhotos: string[];
  status: 'pending' | 'reviewed' | 'approved';
  notes: string;
}

export interface ProviderProfile {
  id: string;
  name: string;
  city: string;
  rating: string;
  reviews: number;
  verified: boolean;
  activeListings: number;
  completedRentals: number;
  categories: CategoryKey[];
  description: string;
  phone: string;
  email: string;
  avatar?: string;
}

export type Language = 'en' | 'hi';
export type ActiveTab = 'marketplace' | 'resources' | 'providers' | 'how' | 'dashboard';
