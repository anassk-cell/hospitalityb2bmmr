const fs = require('fs');
const index = fs.readFileSync('/tmp/index.js', 'utf8');

// Find all string constants longer than 3 characters
const matches = [];
const regex = /["']([^"'\\]{4,80})["']/g;
let m;
while ((m = regex.exec(index)) !== null) {
  matches.push(m[1]);
}

const interesting = matches.filter(s => 
  s.includes(' ') && 
  !s.includes('{') && 
  !s.includes(';') && 
  !s.includes('calc(') &&
  !s.includes('rgb(') &&
  !s.includes('data-')
);

console.log("Found sentences/phrases count:", interesting.length);
console.log("\nSample phrases:\n", [...new Set(interesting)].slice(0, 100).join('\n'));
